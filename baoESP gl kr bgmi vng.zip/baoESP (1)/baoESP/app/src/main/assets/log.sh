
while true; do
rm -rf /sdcard/MT2
rm -rf /sdcard/MIUI
rm -rf /sdcard/tencent
touch /sdcard/tencent
rm -rf /sdcard/MidasOversea
touch /sdcard/MidasOversea
touch /sdcard/.backups
rm -rf /sdcard/QTAudioEngine
rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json
rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/*
rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
touch /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /data/data/com.vng.pubgmobile/*cache*
rm -rf /data/data/com.vng.pubgmobile/app*
rm -rf /data/data/com.vng.pubgmobile/files
rm -rf /data/data/com.vng.pubgmobile/databases
touch /data/data/com.vng.pubgmobile/files
touch /data/data/com.vng.pubgmobile/app_crashrecord
touch /data/data/com.vng.pubgmobile/cache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/*
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
touch /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /data/data/com.pubg.krmobile/*cache*
rm -rf /data/data/com.pubg.krmobile/app*
rm -rf /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/databases
touch /data/data/com.pubg.krmobile/files
touch /data/data/com.pubg.krmobile/app_crashrecord
touch /data/data/com.pubg.krmobile/cache
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/*
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
touch /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /data/data/com.tencent.ig/*cache*
rm -rf /data/data/com.tencent.ig/app*
rm -rf /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/databases
touch /data/data/com.tencent.ig/files
touch /data/data/com.tencent.ig/app_crashrecord
touch /data/data/com.tencent.ig/cache

rm -rf  /data/data/com.tencent.ig/files
touch /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/app_crashrecord
touch /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/cache/*

rm -rf  /data/data/com.pubg.krmobile/files
touch /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
touch /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/cache/*

rm -rf  /data/data/com.rekoo.pubgm/files
touch /data/data/com.rekoo.pubgm/files
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord
touch /data/data/com.rekoo.pubgm/app_crashrecord
rm -rf /data/data/com.rekoo.pubgm/cache/*

rm -rf  /data/data/com.tencent.iglite/files
touch /data/data/com.tencent.iglite/files
rm -rf /data/data/com.tencent.iglite/app_crashrecord
touch /data/data/com.tencent.iglite/app_crashrecord
rm -rf /data/data/com.tencent.iglite/cache/*

chmod -R 777 /data/data/com.tencent.ig/files/ano_tmp

chmod -R 777 /data/data/com.pubg.krmobile/files/ano_tmp

chmod -R 777 /data/data/com.vng.pubgmobile/files/ano_tmp

chmod -R 777 /data/data/com.rekoo.pubgm/files/ano_tmp



rm -rf /data/data/com.tencent.ig/files/ano_tmp/tssmua.zip
touch /data/data/com.tencent.ig/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.tencent.ig/files/ano_tmp/config3.xml
touch /data/data/com.tencent.ig/files/ano_tmp/config3.xml
rm -rf /data/data/com.tencent.ig/files/ano_tmp/comm.dat
touch /data/data/com.tencent.ig/files/ano_tmp/comm.dat
chmod -R 000 /data/data/com.tencent.ig/files/ano_tmp/tssmua.zip
chmod -R 000 /data/data/com.tencent.ig/files/ano_tmp/config3.xml
chmod -R 000 /data/data/com.tencent.ig/files/ano_tmp/comm.dat

rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/tssmua.zip
touch /data/data/com.pubg.krmobile/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/config3.xml
touch /data/data/com.pubg.krmobile/files/ano_tmp/config3.xml
rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/comm.dat
touch /data/data/com.pubg.krmobile/files/ano_tmp/comm.dat
chmod -R 000 /data/data/com.pubg.krmobile/files/ano_tmp/tssmua.zip
chmod -R 000 /data/data/com.pubg.krmobile/files/ano_tmp/config3.xml
chmod -R 000 /data/data/com.pubg.krmobile/files/ano_tmp/comm.dat

rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/tssmua.zip
touch /data/data/com.vng.pubgmobile/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/config3.xml
touch /data/data/com.vng.pubgmobile/files/ano_tmp/config3.xml
rm -rf /data/data/com.vng.pubgmobile/files/ano_tmp/comm.dat
touch /data/data/com.vng.pubgmobile/files/ano_tmp/comm.dat
chmod -R 000 /data/data/com.vng.pubgmobile/files/ano_tmp/tssmua.zip
chmod -R 000 /data/data/com.vng.pubgmobile/files/ano_tmp/config3.xml
chmod -R 000 /data/data/com.vng.pubgmobile/files/ano_tmp/comm.dat


rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/tssmua.zip
touch /data/data/com.rekoo.pubgm/files/ano_tmp/tssmua.zip
rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/config3.xml
touch /data/data/com.rekoo.pubgm/files/ano_tmp/config3.xml
rm -rf /data/data/com.rekoo.pubgm/files/ano_tmp/comm.dat
touch /data/data/com.rekoo.pubgm/files/ano_tmp/comm.dat
chmod -R 000 /data/data/com.rekoo.pubgm/files/ano_tmp/tssmua.zip
chmod -R 000 /data/data/com.rekoo.pubgm/files/ano_tmp/config3.xml
chmod -R 000 /data/data/com.rekoo.pubgm/files/ano_tmp/comm.dat

chmod 500 /data/data/com.tencent.ig/files/ano_tmp

chmod 500 /data/data/com.pubg.krmobile/files/ano_tmp

chmod 500 /data/data/com.vng.pubgmobile/files/ano_tmp

chmod 500 /data/data/com.rekoo.pubgm/files/ano_tmp

echo "                 By rayansyed77             "
rm -rf /sdcard/MT2
rm -rf /sdcard/MIUI
rm -rf /sdcard/tencent
touch /sdcard/tencent
rm -rf /sdcard/MidasOversea
touch /sdcard/MidasOversea
touch /sdcard/.backups
rm -rf /sdcard/QTAudioEngine
rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json
rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/*
rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
touch /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /data/data/com.vng.pubgmobile/*cache*
rm -rf /data/data/com.vng.pubgmobile/app*
rm -rf /data/data/com.vng.pubgmobile/files
rm -rf /data/data/com.vng.pubgmobile/databases
touch /data/data/com.vng.pubgmobile/files
touch /data/data/com.vng.pubgmobile/app_crashrecord
touch /data/data/com.vng.pubgmobile/cache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/*
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
touch /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /data/data/com.pubg.krmobile/*cache*
rm -rf /data/data/com.pubg.krmobile/app*
rm -rf /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/databases
touch /data/data/com.pubg.krmobile/files
touch /data/data/com.pubg.krmobile/app_crashrecord
touch /data/data/com.pubg.krmobile/cache
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*.json
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/*
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
touch /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
touch /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /data/data/com.tencent.ig/*cache*
rm -rf /data/data/com.tencent.ig/app*
rm -rf /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/databases
touch /data/data/com.tencent.ig/files
touch /data/data/com.tencent.ig/app_crashrecord
touch /data/data/com.tencent.ig/cache
echo "Auto Cleaner"
echo 
done
sleep 5

echo "@pakgamerz"