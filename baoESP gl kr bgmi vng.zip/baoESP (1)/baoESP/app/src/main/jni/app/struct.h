#include <string>
#define maxLingCount 100
using namespace std;

class Color {
public:
    int colour;
    Color() {
        this->colour = 0;
    }
    Color(int colour) {
    this->colour = colour;
    }
};

struct Vector3A {
    float x, y, z;
};
class Vector2A {
        public:
        float x;
        float y;

        Vector2A() {
            this->x = 0;
            this->y = 0;
        }

        Vector2A(float x, float y) {
            this->x = x;
            this->y = y;
        }

        static Vector2A Zero() {
            return Vector2A(0.0f, 0.0f);
        }

        bool operator!=(const Vector2A &src) const {
            return (src.x != x) || (src.y != y);
        }

        Vector2A &operator+=(const Vector2A &v) {
            x += v.x;
            y += v.y;
            return *this;
        }

        Vector2A &operator-=(const Vector2A &v) {
            x -= v.x;
            y -= v.y;
            return *this;
        }
};

enum Mode
{
	InitMode = 1,
	ESPMode = 2,
	HackMode = 3,
	StopMode = 4,
};

struct Fengling
{
	bool BulletMode,BulletModePlayer,BulletModeSingle;
	int ScreenWidth;
	int ScreenHeight;
	int aimingRange;
	int aimbotmode = 1;
	int FlyingSleep;
	int screenWidth = -1,screenHeight = -1;
};

struct SetFeng
{
	int mode;
	int type;
	int px = -1;
	int py = -1;
	int Game;
	int GameBit;
};

struct ItemData {
    char ItemName[50];
    float x;
	float y;
	float w;
    float Distance;
};

struct LingData
{
	float x;
	float y;
	float w;
	float h;
	int Distance;
	int Health;
	int isBot;
	int State;
	int TeamID;
	float Unhealthy;
	char PlayerName[100];
	Vector2A Radar;
	Vector2A Head;
	Vector2A Chest;
	Vector2A Pelvis;
	Vector2A Left_Shoulder;
	Vector2A Right_Shoulder;
	Vector2A Left_Elbow;
	Vector2A Right_Elbow;
	Vector2A Left_Wrist;
	Vector2A Right_Wrist;
	Vector2A Left_Thigh;
	Vector2A Right_Thigh;
	Vector2A Left_Knee;
	Vector2A Right_Knee;
	Vector2A Left_Ankle;
	Vector2A Right_Ankle;
	int BulletPlayer;
	int RadarX,RadarY;
	int GunBullets;
};

struct Resling {
	bool open;//绘图开关
	int LingCount;				// 数据遍历
	LingData Data[maxLingCount];
	int PlayerCount,BotCount;
};
