#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include "Includes.h"
#include "jni.h"

void ImGColor()
{
    ImGui::CreateContext();
        ImGuiStyle *style = &ImGui::GetStyle();
        ImGui::StyleColorsDark();
        /*style->FrameRounding = 8.0f;
        style->WindowRounding = 8.0f;
        style->GrabRounding = 8.0f;*/
        style->FrameBorderSize = 8.0f;

        style->Colors[ImGuiCol_Text]                  = ImColor(255, 255, 255, 255);
        style->Colors[ImGuiCol_TextDisabled]          = ImVec4(0.60f, 0.60f, 0.60f, 1.00f);
        style->Colors[ImGuiCol_WindowBg]              = ImColor(0, 0, 0, 255);
        style->Colors[ImGuiCol_ChildBg]               = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
        style->Colors[ImGuiCol_PopupBg]               = ImVec4(0.05f, 0.05f, 0.10f, 0.85f);
        style->Colors[ImGuiCol_Border]                = ImColor(255, 0, 0, 255);
        style->Colors[ImGuiCol_BorderShadow]          = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
        style->Colors[ImGuiCol_FrameBg]               = ImColor(255, 255, 255, 0);
        style->Colors[ImGuiCol_FrameBgActive]         = ImColor(255, 255, 255, 0);
        style->Colors[ImGuiCol_FrameBgHovered]        = ImColor(255, 255, 255, 0);
        style->Colors[ImGuiCol_TitleBg]               = ImColor(255, 0, 0, 255);
        style->Colors[ImGuiCol_TitleBgActive]         = ImColor(255, 0, 0, 255);
        style->Colors[ImGuiCol_TitleBgCollapsed]      = ImColor(0, 0, 0, 100);
        style->Colors[ImGuiCol_MenuBarBg]             = ImVec4(1.0f, 1.0f, 1.0f, 0.80f);
        style->Colors[ImGuiCol_ScrollbarBg]           = ImVec4(0.20f, 0.25f, 0.30f, 0.60f);
        style->Colors[ImGuiCol_ScrollbarGrab]         = ImVec4(0.55f, 0.53f, 0.55f, 0.51f);
        style->Colors[ImGuiCol_ScrollbarGrabHovered]  = ImVec4(0.56f, 0.56f, 0.56f, 1.00f);
        style->Colors[ImGuiCol_ScrollbarGrabActive]   = ImVec4(0.56f, 0.56f, 0.56f, 0.91f);
        style->Colors[ImGuiCol_CheckMark]             = ImVec4(0.39f, 1.72f, 0.57f, 1.00f);
        style->Colors[ImGuiCol_SliderGrab]            = ImVec4(0.70f, 0.70f, 0.70f, 0.62f);
        style->Colors[ImGuiCol_SliderGrabActive]      = ImVec4(0.30f, 0.30f, 0.30f, 0.84f);
        style->Colors[ImGuiCol_Separator]             = ImColor(70, 70, 70, 255);
        style->Colors[ImGuiCol_SeparatorActive]       = ImColor(76, 76, 76, 255);
        style->Colors[ImGuiCol_SeparatorHovered]      = ImColor(76, 76, 76, 255);
        style->Colors[ImGuiCol_Button]                = ImColor(60, 60, 60, 255);
        style->Colors[ImGuiCol_ButtonActive]          = ImColor(60, 60, 60, 255);
        style->Colors[ImGuiCol_ButtonHovered]         = ImColor(255, 0, 0, 255);
        style->Colors[ImGuiCol_Header]                = ImColor(0, 0, 0, 0);
        style->Colors[ImGuiCol_HeaderActive]          = ImColor(0, 0, 0, 0);
        style->Colors[ImGuiCol_HeaderHovered]         = ImColor(255, 0, 0, 255);
        style->Colors[ImGuiCol_ResizeGrip]            = ImColor(255, 0, 0, 255);
        style->Colors[ImGuiCol_ResizeGripHovered]     = ImColor(255, 0, 0, 255);
        style->Colors[ImGuiCol_ResizeGripActive]      = ImColor(255, 0, 0, 255);
        style->Colors[ImGuiCol_PlotLines]             = ImVec4(0.0f, 1.0f, 0.0f, 0.90f);
        style->Colors[ImGuiCol_PlotLinesHovered]      = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
        style->Colors[ImGuiCol_PlotHistogram]         = ImVec4(0.0f, 1.0f, 0.0f, 0.90f);
        style->Colors[ImGuiCol_PlotHistogramHovered]  = ImVec4(0.0f, 1.0f, 0.0f, 0.90f);
        style->Colors[ImGuiCol_TextSelectedBg]        = ImVec4(0.00f, 0.00f, 1.00f, 0.35f);
        
       // style->ScaleAllSizes(std::max(1.0f, density / 150.0f));
        style->ScrollbarSize *= 0.5f;
        
    //整体控件大小
    ImGui::GetStyle().ScaleAllSizes(3.0f);
    // 内距 就是控件距离
    style->ScaleAllSizes(1.5f);
    // 窗口菜单按钮位置(就是窗口标题的那个三角形)(-1无 0左 1右)
    style->WindowMenuButtonPosition = 0;
    // 窗体边框圆角
    style->WindowRounding = 20.0f;
    // 框架圆角(比如设置复选框的圆角)
    style->FrameRounding = 10.0f;
    // 框架描边宽度
    style->FrameBorderSize = 0.3f;
    // 滚动条圆角
    style->ScrollbarRounding = 5.0f;
    // 滚动条宽度
    style->ScrollbarSize = 40.0f;
    // 滑块圆角
    style->GrabRounding = 8.0f;
    // 滑块宽度
    style->GrabMinSize = 20.0f;
}

void 写入文件(string luj,int shuzhi)
{
    //luj.c_str();
    char b[64];
    int fd = open(luj.c_str(), O_WRONLY | O_CREAT);
    sprintf(b,"%d",shuzhi);
    write(fd, &b , sizeof(b));   // 写入文本                                              // close(fd); 
    close(fd);
}



string 获取动作(int 动作id)
{
    string 动作名字 = "未知";
    if (动作id == 0)
    {
        动作名字 = "静止";
    }
    if (动作id == 1)
    {
        动作名字 = "移动";
    }
    if (动作id == 8)
    {
        动作名字 = "站立";
    }
    if (动作id == 9)
    {
        动作名字 = "行走";
    }
    if (动作id == 11 || 动作id == 10)
    {
        动作名字 = "奔跑";
    }
    if (动作id == 16)
    {
        动作名字 = "蹲下";
    }
    if (动作id >= 17 && 动作id <= 19)
    {
        动作名字 = "蹲走";
    }
    if (动作id >= 33 && 动作id <= 35)
    {
        动作名字 = "爬动";
    }
    if (动作id == 32)
    {
        动作名字 = "趴下";
    }
    if (动作id >= 60 && 动作id <= 100)
    {
        动作名字 = "跳跃";
    }
    if (动作id >= 260 && 动作id <= 290)
    {
        动作名字 = "换弹";
    }
    if (动作id >= 120 && 动作id <= 170 || 动作id >= 630 && 动作id <= 680)
    {
        动作名字 = "射击";
    }
    if (动作id >= 500 && 动作id <= 550 || 动作id >= 1500 && 动作id <= 1550)
    {
        动作名字 = "瞄人";
    }
    if (动作id >= 1150 && 动作id <= 1170 || 动作id >= 1670 && 动作id <= 1700)
    {
        动作名字 = "射击";
    }
    if (动作id >= 1020 && 动作id <= 1060 || 动作id >= 1530 && 动作id <= 1560)
    {
        动作名字 = "探头";
    }
    if (动作id >= 2040 && 动作id <= 2090 || 动作id >= 3080 && 动作id <= 3090)
    {
        动作名字 = "切枪";
    }
    if (动作id >= 8200 && 动作id <= 8270)
    {
        动作名字 = "挥拳";
    }
    if (动作id == 131072)
    {
        动作名字 = "倒地";
    }
    if (动作id == 131073)
    {
        动作名字 = "倒地";
    }
    if (动作id == 262144)
    {
        动作名字 = "死亡";
    }
    if (动作id == 524296)
    {
        动作名字 = "射击";
    }
    if (动作id >= 65540 && 动作id <= 65580)
    {
        动作名字 = "打药";
    }
    if (动作id >= 16390 && 动作id <= 16420 || 动作id >= 17410 && 动作id <= 17430)
    {
        动作名字 = "投掷";
    }
    if (动作id >= 3140000 && 动作id <= 3170000)
    {
        动作名字 = "探头";
    }
    if (动作id >= 3146240 && 动作id <= 3146250)
    {
        动作名字 = "瞄人";
    }
    if (动作id >= 4194300 && 动作id <= 4194310)
    {
        动作名字 = "游泳";
    }
    if (动作id == 524288)
    {
        动作名字 = "开船";
    }
    if (动作id == 524296)
    {
        动作名字 = "开车";
    }
    if (动作id == 1048584)
    {
        动作名字 = "坐车";
    }
    if (动作id == 1050632)
    {
        动作名字 = "收枪";
    }
    if (动作id == 1048576 || 动作id == 1050624)
    {
        动作名字 = "坐船";
    }
    if (动作id >= 16000000 && 动作id <= 17000000)
    {
        动作名字 = "攀爬";
    }
    if (动作id == 268435464)
    {
        动作名字 = "鼓掌";
    }
    if (动作id >= -2147483640 && 动作id <= -2000000000)
    {
        动作名字 = "拍打";
    }
    return 动作名字;
}

/*string 获取枪械(int 枪械id)
{
    string 枪械名字 = "未知";
    if (枪械id == 0)
    {
        枪械名字 = "空手";
    }
    if (枪械id == 101001)
    {
        枪械名字 = "AKM";
    }
    if (枪械id == 101002)
    {
        枪械名字 = "M16A4";
    }
    if (枪械id == 101003)
    {
        枪械名字 = "SCAR-L";
    }
    if (枪械id == 101005)
    {
        枪械名字 = "GROZA";
    }
    if (枪械id == 101006)
    {
        枪械名字 = "AUG";
    }
    if (枪械id == 101007)
    {
        枪械名字 = "QBZ";
    }
    if (枪械id == 101008)
    {
        枪械名字 = "M762";
    }
    if (枪械id == 101009)
    {
        枪械名字 = "MK47";
    }
    if (枪械id == 101010)
    {
        枪械名字 = "G36C";
    }
    if (枪械id == 101011)
    {
        枪械名字 = "AC-VAL";
    }
    if (枪械id == 102001)
    {
        枪械名字 = "UZI";
    }
    if (枪械id == 102002)
    {
        枪械名字 = "UMP45";
    }
    if (枪械id == 102003)
    {
        枪械名字 = "Vector";
    }
    if (枪械id == 102004)
    {
        枪械名字 = "汤姆逊";
    }
    if (枪械id == 102005)
    {
        枪械名字 = "野牛";
    }
    if (枪械id == 102006)
    {
        枪械名字 = "MPK5";
    }
    if (枪械id == 102007)
    {
        枪械名字 = "P90";
    }
    return 枪械名字;
}
*/

