
#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include "struct.h"
#include "jancok.h"
#include "Includes.h"
#include "jni.h"
#include "TTF/OPPOSans-H.h"
#include "ImG.h"

//#include "base64/base64.h"
//std::string const info = "baoad";
SetFeng ng{};
char Dis[50];
char mz[32];
ImFont *font;
Fengling fengling;
Resling resling;
char extra[32],extra2[32];
Color 方框颜色;
float x,y,w,h,head;
float xw,TOP,BUTTOM;
int LingCount;//数据遍历
bool hzcsh,English,Root,NoRoot,hzSock;
int Socket = 0;
int style_id = 0;
//vhar *baoESP = ((char[]){'b', 'a', 'o', 'E', 'S', 'P', ' ', '1', '.', '7', '.', '3', ' ', '-', ' ', '3', '2', 'B', 'i', 't'});
//char* baoText = ((char[]){'T', 'G', '-', '>', '@','K','e', 'v', 'i', 'n', 'Y', 'Y', 'D', 'S', '\n', 'Q', 'Q', '-', '>', '7', '2', '4', '8', '7', '3', '2', '2', '3', '\n', 'F', 'P', 'S', '-', '>', '%.1f'});
int screenWidth = -1, glWidth, screenHeight = -1, glHeight;
bool g_Initialized = false;
ImGuiWindow* g_window = NULL;
using namespace std;
char *buf = NULL;				// 设置缓冲区
char *rtn = NULL;				// 设置缓冲区
int len,sockCheck;
string baoESP = "pakgamerz",GameName,Rootstring,BitName;
float density = -1;


// jstring转换char*
char *jstringToChar(JNIEnv * env, jstring jstr)
{
    jclass clsstring = env->FindClass("java/lang/String");
    jstring strencode = env->NewStringUTF("utf-8");
	jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
	jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
	jsize alen = env->GetArrayLength(barr);
	jbyte *ba = env->GetByteArrayElements(barr, JNI_FALSE);
	if (alen > 0)
	{
		rtn = (char *)malloc(alen + 1);
		memcpy(rtn, ba, alen);
		rtn[alen] = 0;
	}
	env->ReleaseByteArrayElements(barr, ba, 0);
	return rtn;
}
#include <iostream>
int toUnicode(const char* str)
{
    return str[0] + (str[1] ? toUnicode(str + 1) : 0);
}

extern "C" {
    JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_init(JNIEnv* env, jclass cls);
    JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_resize(JNIEnv* env, jobject obj, jint width, jint height);
    JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_step(JNIEnv* env, jobject obj);
	JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_imgui_Shutdown(JNIEnv* env, jobject obj);
	JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_MotionEventClick(JNIEnv* env, jobject obj,jboolean down,jfloat PosX,jfloat PosY);
	JNIEXPORT jstring JNICALL Java_com_baoad_ESP_GLES3JNIView_getWindowRect(JNIEnv *env, jobject thiz);
	JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_Mode(JNIEnv* env, jobject obj, jint Game, jint RootMode, jint GameBit);
};


JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_init(JNIEnv * env, jclass cls)
{
    // 设置ImGui上下文
    if (g_Initialized)
        return;
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO & io = ImGui::GetIO();

    io.IniFilename = NULL;

    // 设置ImGui风格
    //ImGui::StyleColorsDark(); // 设置主题[黑]
    //ImGui::StyleColorsClassic(); // 设置主题[紫]
    ImGColor();  // 设置主题
    // ImGui::StyleColorsDark(); // 设置主题[蓝]
	//ImGuiColor();

    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init("#version 300 es");

    
	ImFontConfig font_cfg;
    font_cfg.FontDataOwnedByAtlas = false;
    ImFont *font = io.Fonts->AddFontFromMemoryTTF((void *) OPPOSans_H, OPPOSans_H_size, 35.0f, &font_cfg, io.Fonts->GetGlyphRangesChineseFull());
    IM_ASSERT(font != NULL);
    
    g_Initialized = true;
}

JNIEXPORT void JNICALL
Java_com_baoad_ESP_GLES3JNIView_resize(JNIEnv *env, jobject obj, jint width, jint height)
{
    screenWidth = (int) width;
    screenHeight = (int) height;
	glViewport(0, 0, width, height);
	ImGuiIO &io = ImGui::GetIO();
    io.ConfigWindowsMoveFromTitleBarOnly = true;
    io.IniFilename = NULL;
	ImGui::GetIO().DisplaySize = ImVec2((float)width, (float)height);
}
static int i1 =0;


/************用户自定义**************/
ImColor boxColor = ImColor(116,186,143);
ImColor lineColor = ImColor(212, 193,40, 255);
ImColor ggColor = ImColor(255, 48, 48);
ImColor gugeColor = ImColor(248, 248, 255);
ImColor headColor = ImColor(255, 48, 48);
ImColor wordColor = ImColor(255, 185, 15);
                         
/*****绘制*****/
bool 方框;
bool 射线;
bool 动作;
bool 昵称;
bool 距离;
bool 血量;
bool 背敌;
bool 骨骼;
bool 绘制;
bool 队伍;
bool 人数;
bool 全开;
bool 子弹;
bool 全关;
bool 玩家;
/******自瞄*****/
bool 头部方框;
bool 雷达;
bool 自瞄;
bool 头部;
bool 胸部;
bool 脚部;
bool 子追关闭;


void ESP()
{

	
    sprintf(Dis, "telegram @pakgamerz", ImGui::GetIO().Framerate);
    ImGui::GetForegroundDrawList()->AddText(font, 40, ImVec2(screenWidth / 7, screenHeight - 150), ImColor(255, 185, 15), Dis);
    if (fengling.BulletMode)
    {
        ImGui::GetForegroundDrawList()->AddCircle(ImVec2(screenWidth / 2, screenHeight / 2), fengling.aimingRange, ggColor, 64, 2.0f);
    }
    if (全开)
    {
        方框 = true;
        射线 = true;
        动作 = true;
        昵称 = true;
        距离 = true;
        血量 = true;
        背敌 = true;
        骨骼 = true;
        绘制 = true;
        队伍 = true;
        人数 = true;
        雷达 = true;
		子弹 = true;
    }
	if (全关)
    {
        方框 = false;
        射线 = false;
        动作 = false;
        昵称 = false;
        距离 = false;
        血量 = false;
        背敌 = false;
        骨骼 = false;
        绘制 = false;
        队伍 = false;
        人数 = false;
        雷达 = false;
		子弹 = false;
		全关 = false;
    }
    send((void *)&fengling, sizeof(fengling));
	receive((void *)&resling);
    if (resling.open)
    {

        for (int i = 0; i < resling.LingCount; i++)
        {
            float AimDistance = 1024;
            int BulletX = 0,BulletY = 0;
			
            x=resling.Data[i].x;
            y=resling.Data[i].y;
            w=resling.Data[i].w;
            
            xw =x+w/2;
            TOP = y - w;
			BUTTOM = y + w;
			
			if (resling.Data[i].isBot == 0 && 玩家 || !玩家)
			{

            if (人数)
            {
                sprintf(extra, "真人:%d", resling.PlayerCount);
				sprintf(extra2, "人机:%d", resling.BotCount);
                ImGui::GetForegroundDrawList()->AddText(font,40,ImVec2(screenWidth/2-130, screenHeight/13), ImColor(255,48,48), extra);
				ImGui::GetForegroundDrawList()->AddText(font,40,ImVec2(screenWidth/2+20, screenHeight/13), ImColor(212, 193,40, 255), extra2);
				ImGui::GetForegroundDrawList()->AddText(font,40,ImVec2(screenWidth/2, screenHeight/13), ImColor(190, 190, 190), "|");
				//ImGui::GetForegroundDrawList()->AddRectFilled({screenWidth/2 - 45 , 40}, {screenWidth/2 + 55 , 84},ImColor(0, 205,0, 80));
            }
            if (雷达 && resling.Data[i].Distance <= 250)
            {
                if (resling.Data[i].isBot == 0)
                {
                    ImGui::GetForegroundDrawList()->AddCircleFilled({screenWidth/3 + resling.Data[i].RadarX, screenHeight/3 + resling.Data[i].RadarY}, 5, ImColor(255, 48, 48));
                }
                else if (resling.Data[i].isBot == 1)
                {
                    ImGui::GetForegroundDrawList()->AddCircleFilled({screenWidth/3 + resling.Data[i].RadarX, screenHeight/3 + resling.Data[i].RadarY}, 5, ImColor(212, 193,40, 255));
                }
               // ImGui::GetForegroundDrawList()->AddCircleFilled({screenWidth/3, screenHeight/3}, 2, gugeColor);
				ImGui::GetForegroundDrawList()->AddCircleFilled({screenWidth/3, screenHeight/3}, 5, ImColor(0, 255, 255), 1);
				ImGui::GetForegroundDrawList()->AddCircle({screenWidth/3, screenHeight/3}, 32, gugeColor, 32, {1});
				ImGui::GetForegroundDrawList()->AddCircle({screenWidth/3, screenHeight/3}, 96, gugeColor, 32, {1});
				ImGui::GetForegroundDrawList()->AddCircle({screenWidth/3, screenHeight/3}, 192, gugeColor, 64, {1});
				//ImGui::GetForegroundDrawList()->AddCircle({screenWidth/3, screenHeight/3}, 288, gugeColor, 64, {1});
				ImGui::GetForegroundDrawList()->AddLine({screenWidth/3 - 192, screenHeight/3}, {screenWidth/3 + 192, screenHeight/3}, gugeColor, {1});
				ImGui::GetForegroundDrawList()->AddLine({screenWidth/3, screenHeight/3 - 192}, {screenWidth/3, screenHeight/3 + 192}, gugeColor, {1});
            }
            if (背敌)
            {
                sprintf(extra, "[%d]", resling.Data[i].Distance);
                if (resling.Data[i].isBot == 1){
                    if (x + (w / 2) < 0)
                    {
                        ImGui::GetForegroundDrawList()->AddText(font, 40, ImVec2(0, y), wordColor, extra);
                    }
                    else if (x - (w / 2) > screenWidth)
                    {
                        ImGui::GetForegroundDrawList()->AddText(font, 40, ImVec2(screenWidth, y), wordColor, extra);
                    }
                    else if (y + w < 0)
                    {
                        ImGui::GetForegroundDrawList()->AddText(font, 40, ImVec2(x, 5), wordColor, extra);
                    }
                }
                else if (resling.Data[i].isBot == 0)
                {
                    if (x + (w / 2) < 0)
                    {
                        ImGui::GetForegroundDrawList()->AddText(font, 40, ImVec2(0, y), headColor, extra);
                    }
                    else if (x - (w / 2) > screenWidth)
                    {
                        ImGui::GetForegroundDrawList()->AddText(font, 40, ImVec2(screenWidth, y), headColor, extra);
                    }
                    else if (y + w < 0)
                    {
                        ImGui::GetForegroundDrawList()->AddText(font, 40, ImVec2(x, 55), headColor, extra);
                    }
                }
            }

            if (w > 0)
            {
                if (射线)
                {
                    if (resling.Data[i].isBot == 0)
                    {
                        ImGui::GetForegroundDrawList()->AddLine({screenWidth / 2, screenHeight/13}, {xw, TOP}, ImColor(255, 48, 48), {1});
                    }
                    else if (resling.Data[i].isBot == 1 && resling.Data[i].TeamID != 996)
                    {
                        ImGui::GetForegroundDrawList()->AddLine({screenWidth / 2, screenHeight/13}, {xw, TOP}, lineColor, {1});
                    }
					else if (resling.Data[i].TeamID == 996)
                    {
                        ImGui::GetForegroundDrawList()->AddLine({screenWidth / 2, screenHeight/13}, {xw, TOP}, ImColor(248, 248, 255), {1});
                    }
                }
                /*
				if (fengling.BulletMode)
				{
					ImGui::GetForegroundDrawList()->AddLine({screenWidth/2, screenHeight/2}, {resling.Data[i].MinBulleterX, resling.Data[i].MinBulleterY},ImColor(255,48,48), {1});
				}
					*/
            }
            if (x != 0 && y != 0 && w > 0  )
            {
                if (方框)
                {
                    ImGui::GetForegroundDrawList()->AddRect({x , TOP}, {x +w, BUTTOM},boxColor, {2.5}, 5,{2.5});
                }
               /*if(头部方框){
                   ImGui::GetForegroundDrawList()->AddCircle({x,y-w/4},5,boxColor);
               }*/
                if (血量)
                {
                    if (resling.Data[i].TeamID != 996)
                    {
                        ImGui::GetForegroundDrawList()->AddRect({xw - 101, TOP - 20}, {xw + 101, TOP - 25}, ImColor(0, 0, 0));
                        if (resling.Data[i].Health > 100)
                        {
                            ImGui::GetForegroundDrawList()->AddRectFilled({xw - 100, TOP - 20}, {xw + 100, TOP - 25}, ImColor(0, 191, 255, 122));
                        }
                        else if (resling.Data[i].Health > 0 && resling.Data[i].Health <= 100)
                        {
                            ImGui::GetForegroundDrawList()->AddRectFilled({xw - 100, TOP - 20}, {xw - 100 + resling.Data[i].Health * 2, TOP - 25}, ImColor(51, 255, 34, 122));
                        }
                        else if (resling.Data[i].Health <= 0)
                        {
                            ImGui::GetForegroundDrawList()->AddRectFilled({xw - 100, TOP - 20}, {xw - 100 + resling.Data[i].Unhealthy * 2, TOP - 25}, ImColor(255, 48, 48, 122));
                        }
                    }
                    else
                    {
                        sprintf(extra, "[%d]", resling.Data[i].Health);
						ImGui::GetForegroundDrawList()->AddText(font,29,ImVec2(xw-105,TOP-55), wordColor, extra);
                    }
                }
                if (距离)
                {
                    sprintf(extra, "[%d]", resling.Data[i].Distance);
                    ImGui::GetForegroundDrawList()->AddText(font, 29, ImVec2(xw - 10, BUTTOM + 10), wordColor, extra);
                }
                if (昵称)
                {
                    sprintf(extra, "%s", resling.Data[i].PlayerName);
                    ImGui::GetForegroundDrawList()->AddText(font, 29, ImVec2(xw - 60, TOP - 55), wordColor, extra);
                }
                if (resling.Data[i].TeamID != 996)
                {
                    if (队伍)
                    {
                        sprintf(extra, ".%d.", resling.Data[i].TeamID);
                        ImGui::GetForegroundDrawList()->AddText(font, 29, ImVec2(xw - 103, TOP - 55), wordColor, extra);
                    }
                    if (动作)
                    {
                        sprintf(extra, "[%s]", 获取动作(resling.Data[i].State).c_str());
                        ImGui::GetForegroundDrawList()->AddText(font, 29, ImVec2(xw - 98, TOP - 20), wordColor, extra);
                    }
					if (子弹)
					{
						if (resling.Data[i].GunBullets > 0)
                        {
                            sprintf(extra, "[%d]", resling.Data[i].GunBullets);
                            ImGui::GetForegroundDrawList()->AddText(font, 29, ImVec2(xw + 40, TOP - 20), wordColor, extra);
                        }
                    }
                }
                if (骨骼)
                {
                    if (resling.Data[i].TeamID != 996)
                    {
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Head.x, resling.Data[i].Head.y}, {resling.Data[i].Chest.x, resling.Data[i].Chest.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Chest.x, resling.Data[i].Chest.y}, {resling.Data[i].Pelvis.x, resling.Data[i].Pelvis.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Chest.x, resling.Data[i].Chest.y}, {resling.Data[i].Left_Shoulder.x, resling.Data[i].Left_Shoulder.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Chest.x, resling.Data[i].Chest.y}, {resling.Data[i].Right_Shoulder.x, resling.Data[i].Right_Shoulder.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Left_Shoulder.x, resling.Data[i].Left_Shoulder.y}, {resling.Data[i].Left_Elbow.x, resling.Data[i].Left_Elbow.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Right_Shoulder.x, resling.Data[i].Right_Shoulder.y}, {resling.Data[i].Right_Elbow.x, resling.Data[i].Right_Elbow.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Left_Elbow.x, resling.Data[i].Left_Elbow.y}, {resling.Data[i].Left_Wrist.x, resling.Data[i].Left_Wrist.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Right_Elbow.x, resling.Data[i].Right_Elbow.y}, {resling.Data[i].Right_Wrist.x, resling.Data[i].Right_Wrist.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Pelvis.x, resling.Data[i].Pelvis.y}, {resling.Data[i].Left_Thigh.x, resling.Data[i].Left_Thigh.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Pelvis.x, resling.Data[i].Pelvis.y}, {resling.Data[i].Right_Thigh.x, resling.Data[i].Right_Thigh.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Left_Thigh.x, resling.Data[i].Left_Thigh.y}, {resling.Data[i].Left_Knee.x, resling.Data[i].Left_Knee.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Right_Thigh.x, resling.Data[i].Right_Thigh.y}, {resling.Data[i].Right_Knee.x, resling.Data[i].Right_Knee.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Left_Knee.x, resling.Data[i].Left_Knee.y}, {resling.Data[i].Left_Ankle.x, resling.Data[i].Left_Ankle.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddLine({resling.Data[i].Right_Knee.x, resling.Data[i].Right_Knee.y}, {resling.Data[i].Right_Ankle.x, resling.Data[i].Right_Ankle.y}, gugeColor, {1.2});
                        ImGui::GetForegroundDrawList()->AddCircle({resling.Data[i].Head.x, resling.Data[i].Head.y}, w / 10, headColor, 16, {1.2});
                    }
					}
                }
            }
        }
    }
}

void gnzx()
{
    if (hzcsh)
    {
        if (Root)
        {
            std::thread Threadgjhzr(system, "su -c /data/data/com.baoad.ESP/files/assets/baoad");
            Threadgjhzr.detach();
        }
        if (NoRoot)
        {
            std::thread Threadgjhzn(system, "/data/data/com.baoad.ESP/files/assets/baoad");
            Threadgjhzn.detach();
        }
		std::thread Threadgjhzq(system, "chmod 777 /data/data/com.baoad.ESP/files/assets/baoad");
        Threadgjhzq.detach();
        hzcsh = false;
    }
}

//static float f = 150.0f;//自瞄初始范围
/************用户自定义**************/

static bool show_ChildMenu1 = false;
static bool show_ChildMenu2 = false;
static bool show_ChildMenu3 = true;
static bool show_ChildMenu4 = false;



void BeginDraw()
{
	
                        switch (ng.Game)
                        {
                        case 1:
							GameName = "GLOBAL 2.2.0";
                            break;
                        case 2:
							GameName = "VIETNAM 2.2.0";
                            break;
                        case 3:
							GameName = "KOREA 2.2.0";
                            break;
                        case 4:
							GameName = "CHN TAIWAN 2.2.0";
                            break;
                        case 5:
							GameName = "BGMI 2.2.0";
                            break;
						case 6:
							GameName = "BETA 2.w.4";
                            break;
						case 7:
							GameName = "TGMP ";
                            break;
						case 8:
							GameName = "BETATGMP ";
                            break;
                        }
						switch (ng.GameBit)
                        {
                        case 4:
							BitName = "32Bit";
                            break;
						case 8:
							BitName = "64Bit";
                            break;
                        }
	if (Root == true)
	{
		Rootstring = "Root";
	}
	else if (NoRoot == true)
	{
		Rootstring = "NoRoot";
	}
    ImGuiIO & io = ImGui::GetIO();
    // 设置下一个窗口的高宽 
    ImGui::SetNextWindowSize(ImVec2(850, 650), ImGuiCond_Once);
    if (ImGui::Begin((baoESP + " - " + Rootstring + " - " + GameName + " - " + BitName).c_str(),0, ImGuiWindowFlags_NoSavedSettings));
    g_window = ImGui::GetCurrentWindow();
	//ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(1.00f, 1.00f, 1.00f, 0.8f));
    {
        if (ImGui::BeginChild("左侧主菜单", ImVec2(180, 0), false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NavFlattened));
        //ImGui::Text("FPS: %0.2f",io.Framerate);
        {
            if (!English)
            {
                if (ImGui::Button("启动设置"))
                {
                    show_ChildMenu3 = true;
                    show_ChildMenu1 = false;
                    show_ChildMenu2 = false;
					show_ChildMenu4 = false;
                }
                if (ImGui::Button("绘制模块"))
                {
                    show_ChildMenu1 = true;
                    show_ChildMenu2 = false;
                    show_ChildMenu3 = false;
					show_ChildMenu4 = false;
                }
				if (ng.GameBit == 4){
                if (ImGui::Button("子追模块"))
                {
                    show_ChildMenu1 = false;
                    show_ChildMenu2 = true;
                    show_ChildMenu3 = false;
					show_ChildMenu4 = false;
                }
				}
            }
            else if (English)
            {
				
                if (ImGui::Button("Main      "))
                {
                    show_ChildMenu3 = true;
                    show_ChildMenu1 = false;
                    show_ChildMenu2 = false;
					show_ChildMenu4 = false;
                }
                if (ImGui::Button("ESP        "))
                {
                    show_ChildMenu1 = true;
                    show_ChildMenu2 = false;
                    show_ChildMenu3 = false;
					show_ChildMenu4 = false;
                }
				if (ng.GameBit == 4){
                if (ImGui::Button("Bullet     "))
                {
                    show_ChildMenu1 = false;
                    show_ChildMenu2 = true;
                    show_ChildMenu3 = false;
					show_ChildMenu4 = false;
                }
				}
				
            }
			if (ImGui::Button("EXIT      "))
            {
                exit(1);
            }
            //ImGui::Text("卡顿/无效\n重启软件");
            ImGui::Text("FPS: %0.2f",io.Framerate);
            ImGui::EndChild();
        }
        ImGui::SameLine();
        if (show_ChildMenu1)
        {
            if (ImGui::BeginChild("子菜单0", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NavFlattened));
            {
                if (!English)
                {
					if (Socket == 4)
                   {
					   ImGui::Button("Socket链接成功");
                   }
                   else
                   {
                       ImGui::Button("Socket ERROR");
                   }
                    if (全开 == false)
					{
						ImGui::Checkbox("绘图全开", &全开);		
					} 
					else if (全开 == true)
					{
						ImGui::Checkbox("绘图全关", &全关);
						if (全关 == true)
						{
							全开 = false;
						}
					}
                    ImGui::SameLine();
                    if (ImGui::CollapsingHeader("显示选项"))
                    {
						if (ImGui::Button("只显玩家"))
                        {
							玩家 = true, fengling.BulletModePlayer = true;
						}
						ImGui::SameLine();
						if (ImGui::Button("显示全部"))
                        {
							玩家 = false, fengling.BulletModePlayer = false;
						}
                        ImGui::Checkbox("方框", &方框);
                        ImGui::SameLine();
                        ImGui::Checkbox("射线", &射线);
                        ImGui::SameLine();
                        ImGui::Checkbox("动作", &动作);
                        ImGui::Checkbox("昵称", &昵称);
                        ImGui::SameLine();
                        ImGui::Checkbox("距离", &距离);
                        ImGui::SameLine();
                        ImGui::Checkbox("血量", &血量);
                        ImGui::Checkbox("背敌", &背敌);
                        ImGui::SameLine();
                        ImGui::Checkbox("骨骼", &骨骼);
                        ImGui::SameLine();
                        ImGui::Checkbox("雷达", &雷达);
                        ImGui::Checkbox("队伍", &队伍);
                        ImGui::SameLine();
                        ImGui::Checkbox("人数", &人数);
						ImGui::SameLine();
                        ImGui::Checkbox("子弹", &子弹);
						/*
						ImGui::Button("雷达X轴");
						ImGui::SameLine();
						ImGui::SliderInt("", &雷达X, 0, 1024, "%.2f", 1);
						ImGui::Button("雷达Y轴");
						ImGui::SameLine();
						ImGui::SliderInt("", &雷达Y, 0, 1024, "%.2f", 1);
						*/
						
                    }
                    if (ImGui::CollapsingHeader("颜色调节"))
                    {
                        ImGui::ColorEdit3("方框颜色", (float *)&boxColor);
                        ImGui::ColorEdit3("射线颜色", (float *)&lineColor);
                        ImGui::ColorEdit3("骨骼颜色", (float *)&gugeColor);
                        ImGui::ColorEdit3("圈圈颜色", (float *)&ggColor);
                        ImGui::ColorEdit3("文字颜色", (float *)&wordColor);
                    }
                }
                else if (English)
                {
					if (Socket == 4)
                    {
                        ImGui::Button("Socket链接成功");
                    }
                    else
                    {
                        ImGui::Button("Socket ERROR");
                    }
                    if (全开 == false)
					{
						ImGui::Checkbox("ALL OPEN", &全开);		
					} 
					else if (全开 == true)
					{
						ImGui::Checkbox("ALL CLOSE", &全关);
						if (全关 == true)
						{
							全开 = false;
						}
					}
                    ImGui::SameLine();
                    if (ImGui::CollapsingHeader("ESP Option"))
                    {
                        ImGui::Checkbox("Box     ", &方框);
                        ImGui::SameLine();
                        ImGui::Checkbox("Radial  ", &射线);
                        ImGui::SameLine();
                        ImGui::Checkbox("Action  ", &动作);
                        ImGui::Checkbox("Name    ", &昵称);
                        ImGui::SameLine();
                        ImGui::Checkbox("Distance", &距离);
                        ImGui::SameLine();
                        ImGui::Checkbox("Health  ", &血量);
                        ImGui::Checkbox("behind  ", &背敌);
                        ImGui::SameLine();
                        ImGui::Checkbox("Bones   ", &骨骼);
                        ImGui::SameLine();
                        ImGui::Checkbox("Radar   ", &雷达);
                        ImGui::Checkbox("Ranks   ", &队伍);
                        ImGui::SameLine();
                        ImGui::Checkbox("Quantity", &人数);
						ImGui::SameLine();
                        ImGui::Checkbox("Bullets ", &子弹);
                    }
                    if (ImGui::CollapsingHeader("Color Option"))
                    {
                        ImGui::ColorEdit3("Box Color", (float *)&boxColor);
                        ImGui::ColorEdit3("Radial Color", (float *)&lineColor);
                        ImGui::ColorEdit3("Bones Color", (float *)&gugeColor);
                        ImGui::ColorEdit3("BTRange Color", (float *)&ggColor);
                        ImGui::ColorEdit3("Word Color", (float *)&wordColor);
                    }
                }
            }
        }
        if (show_ChildMenu2)
        {
           if (ImGui::BeginChild("子菜单1", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NavFlattened));
           {
               if (!English)
               {
                   if (Socket == 4)
                   {
					   ImGui::Button("Socket链接成功");
					   ImGui::SameLine();
                       ImGui::Checkbox("开启子追", &fengling.BulletMode);
                   }
                   else
                   {
                       ImGui::Button("Socket ERROR");
                   }
                   
                   if (ImGui::Combo("", &style_id, "头部\0胸部\0盆部\0"))
                   {
                       switch (style_id)
                       {
                       case 0:
                           fengling.aimbotmode = 1;
                           break;
                       case 1:
                           fengling.aimbotmode = 2;
                           break;
                       case 2:
                           fengling.aimbotmode = 3;
                           break;
                       }
                   }
                   
                   ImGui::SameLine();
                   ImGui::Button("子追位置");
				   ImGui::Button("子追范围");
                   ImGui::SameLine();
                   ImGui::SliderInt("", &fengling.aimingRange, 0, 1024, "%.2f", 1);
                   if (ImGui::CollapsingHeader("子追设置"))
                   {
                       ImGui::Checkbox("不追人机", &fengling.BulletModePlayer);
                       ImGui::SameLine();
                       ImGui::Checkbox("单发模式", &fengling.BulletModeSingle);
                   }
               }
               else if (English)
               {
                   if (Socket == 4)
                   {
					   ImGui::Button("Connection successful");
					   ImGui::SameLine();
                       ImGui::Checkbox("Bullet tracing", &fengling.BulletMode);
                   }
                   else
                   {
                       ImGui::Button("Socket ERROR");
                   }
                   
                   if (ImGui::Combo("", &style_id, "Head\0Chest\0Pelvis\0"))
                   {
                       switch (style_id)
                       {
                       case 0:
                           fengling.aimbotmode = 1;
                           break;
                       case 1:
                           fengling.aimbotmode = 2;
                           break;
                       case 2:
                           fengling.aimbotmode = 3;
                           break;
                       }
                   }
                   ImGui::SameLine();
                   ImGui::Button("Position");
				   ImGui::Button("BTRange");
                   ImGui::SameLine();
                   ImGui::SliderInt("", &fengling.aimingRange, 0.0f, 1024, "%.2f", 1);

                   if (ImGui::CollapsingHeader("Bullet tracing set"))
                   {
                       ImGui::Checkbox("Not tracing bot", &fengling.BulletModePlayer);
                       ImGui::SameLine();
                       ImGui::Checkbox("Single-shot firearm mode", &fengling.BulletModeSingle);
                   }
               }
           }
        }
		if (show_ChildMenu3)
        {
			if (ImGui::BeginChild("子菜单3", ImVec2(0, 0), false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NavFlattened));
            {
                if (!English)
                {
					if (Socket == 0)
                    {
                        ImGui::Button("Socket未链接");
                        //ImGui::SameLine();
                       // ImGui::Checkbox("初始化", &hzcsh);
                    }
                    else if (Socket == 1)
                    {
                        ImGui::Button("设备接口创建失败");
                        //ImGui::SameLine();
                        //ImGui::Checkbox("重新初始化", &hzcsh);
                    }
                    else if (Socket == 2)
                    {
                        ImGui::Button("运行端口被其他程序占用");
                    }
                    else if (Socket == 3)
                    {
                        ImGui::Button("监听端口被占用");
                    }
                    else if (Socket == 4)
                    {
                        ImGui::Button("Socket链接成功");
                    }
                }
                else if (English)
                {
					if (Socket == 0)
                    {

                        ImGui::Button("Socket Unconnected");
                        //ImGui::SameLine();
                       // ImGui::Checkbox("Initializing", &hzcsh);
                      //  ImGui::Text("GLOBAL/BGMI/KOREA/VIETNAM/CHN TAIWAN/BETA");
                    }
                    else if (Socket == 1)
                    {
                        ImGui::Button("Device interface creation failed");
                        //ImGui::SameLine();
                        //ImGui::Checkbox("Reinitializing", &hzcsh);
                    }
                    else if (Socket == 2)
                    {
                        ImGui::Button("The running port is occupied by another program");
                    }
                    else if (Socket == 3)
                    {
                        ImGui::Button("Port occupied");
                    }
                    else if (Socket == 4)
                    {
                        ImGui::Button("Connection successful");
                    }
                }
				static char str1[128] = "";
				ImGui::InputTextWithHint("##输入卡密", "输入KEY", str1, IM_ARRAYSIZE(str1));
                ImGui::Checkbox("English", &English);
				ImGui::Text("\npakgamerz\nselect english");
					
            }
        }
    }
}
//自定义图形绘制





//结束
void EndDraw()
{
	//ImGuiWindow* window =  ImGui::GetCurrentWindow();
	//window->DrawList->PushClipRectFullScreen();
	ImGui::End();
	//ImGui::PopStyleColor();
}


JNIEXPORT void JNICALL
Java_com_baoad_ESP_GLES3JNIView_step(JNIEnv* env, jobject obj) {
    
	ImGuiIO& io = ImGui::GetIO();
	
	static bool show_demo_window = false;
    static bool show_MainMenu_window = true;
	
	
    
	// Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(screenWidth,  screenHeight);//？设置窗口
    ImGui::NewFrame();
	
    // 1. Show the big demo window (Most of the sample code is in ImGui::ShowDemoWindow()! You can browse its code to learn more about Dear ImGui!).
    //是否显示演示布局
	//ImGui::ShowDemoWindow();
	
	if (show_demo_window)
	{
        ImGui::ShowDemoWindow(&show_demo_window);
	}
	
    
	/*用户自定义区域开始*/
	//主菜单窗口
	if (show_MainMenu_window)
	{
		BeginDraw();
	}
	gnzx();
	
	
	ESP();
	//结束
	EndDraw();
	/*用户自定义区域结束*/
	
    ImGui::Render();
	glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_imgui_Shutdown(JNIEnv* env, jobject obj){
    if (!g_Initialized)
        return;
     // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    g_Initialized=false;
}

JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_MotionEventClick(JNIEnv* env, jobject obj,jboolean down,jfloat PosX,jfloat PosY){
	ImGuiIO & io = ImGui::GetIO();
	io.MouseDown[0] = down;
	io.MousePos = ImVec2(PosX,PosY);
}

JNIEXPORT jstring JNICALL Java_com_baoad_ESP_GLES3JNIView_getWindowRect(JNIEnv *env, jobject thiz) {
    //获取绘制窗口
    // TODO: 实现 getWindowSizePos()
    char result[256]="0|0|0|0";
    if(g_window){
       sprintf(result,"%d|%d|%d|%d",(int)g_window->Pos.x,(int)g_window->Pos.y,(int)g_window->Size.x,(int)g_window->Size.y);
    }
    return env->NewStringUTF(result);
}

JNIEXPORT void JNICALL Java_com_baoad_ESP_GLES3JNIView_Mode(JNIEnv* env, jobject obj, jint Game, jint RootMode, jint GameBit){
	ng.Game = (int) Game;
	ng.GameBit = (int) GameBit;
	if (RootMode == 64)
	{
		Root = true;
	} 
	else if (RootMode == 128)
	{
		NoRoot = true;
	}
}

extern "C"
JNIEXPORT void JNICALL
Java_com_baoad_ESP_MainActivity_getReady(JNIEnv *env, jclass clazz) {
    sockCheck=1;
    if (!Create()) {
        perror("设备接口创建失败\n");
		Socket = 1;
    }
    setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&sockCheck, sizeof(int));
    if (!Bind()) {
        perror("运行端口被其他程序占用\n");
		Socket = 2;
    }
    if (!Listen()) {
        perror("监听端口被占用\n");
		Socket = 3;
    }
    if (Accept()) {
		ng.px = screenWidth;
	    ng.py = screenHeight;
        send((void*)&ng,sizeof(ng));
		Socket = 4;
    }
}
