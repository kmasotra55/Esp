package com.baoad.ESP;

import com.baoad.ESP.R;
import android.app.Service;
import android.os.IBinder;
import android.content.Intent;
import android.os.PowerManager;
import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.os.Build;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.util.DisplayMetrics;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.MotionEvent;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.TextView;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.app.AlertDialog;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.content.SharedPreferences;
import android.widget.RadioButton;
import java.io.File;
import android.graphics.Color;
import android.content.pm.PackageManager;
import android.app.ActivityManager;
import android.widget.Button;
import android.widget.Switch;
import android.widget.CompoundButton;
import java.util.logging.Handler;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.RadioGroup;

public class FloatingActivity extends Service {
	
	private View mainView;
	private WindowManager windowManager;
	private WindowManager.LayoutParams paramsView;
	private LinearLayout mainFloatView;
	private RelativeLayout miniFloatView;
   
	
	@Override
	public IBinder onBind(Intent p1) {
		return null;
	}
	
	@Override
	public void onCreate() {
	   super.onCreate();
       ShowMainView();
	}
	
	private void ShowMainView() {
        mainView = LayoutInflater.from(this).inflate(R.layout.floata, null);
        paramsView = getParams();
  
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.addView(mainView, paramsView);
        InitShowMainView();
    }
	
	private void InitShowMainView() {
		miniFloatView = mainView.findViewById(R.id.miniFloatMenu); //FLOATING LOGO
		mainFloatView = mainView.findViewById(R.id.mainFloatMenu); //FLOATING MENU32
   
		
		LinearLayout closeButton = mainView.findViewById(R.id.closeButton);
		closeButton.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
                    mainFloatView.setVisibility(View.GONE);              
					miniFloatView.setVisibility(View.VISIBLE);
				}
			});
     
            
        //WHEN FLOAT LOGO TOUCHED
        RelativeLayout layoutView = mainView.findViewById(R.id.layoutControlView);
        layoutView.setOnTouchListener(onTouchListener());
        LoadView();//LOAD FUNCTION
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = miniFloatView;
            final View expandedView = mainFloatView;
      
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = paramsView.x;
                        initialY = paramsView.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int Xdiff = (int) (event.getRawX() - initialTouchX);
                        int Ydiff = (int) (event.getRawY() - initialTouchY);
                        if (Xdiff < 10 && Ydiff < 10) {
                            if (isViewCollapsed()) {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                       
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        paramsView.x = initialX + (int) (event.getRawX() - initialTouchX);
                        paramsView.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(mainView, paramsView);
                        return true;
                }
                return false;
            }
        };
    }

    private boolean isViewCollapsed() {
        return mainFloatView == null || miniFloatView.getVisibility() == View.VISIBLE;
    }

    private WindowManager.LayoutParams getParams() {
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            getLayoutType(),
            getFlagsType(),
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 0;
        return params;
    }
            
    private static int getLayoutType() {
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_TOAST;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }
        return LAYOUT_FLAG;
    }

    private int getFlagsType(){
        int LAYOUT_FLAG = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        return LAYOUT_FLAG;
    }
    
		
		
   public void Execute(String path, String toastString) //EXECUTE CPP WITH TOAST
   {
    try
       {
	     ExecuteElf("chmod 777 "+getFilesDir()+path);//VIRTUAL
         ExecuteElf(getFilesDir()+path);
         ExecuteElf("su -c chmod 777 "+getFilesDir()+path);//ROOT
         ExecuteElf("su -c "+getFilesDir()+path);
         Toast.makeText(getApplicationContext(),toastString,Toast.LENGTH_SHORT).show();
         }
         catch(Exception e){
         }
      }
   
    private void ExecuteElf(String shell) //SHELL EXECUTEOR
	{
		try
		{
			Runtime.getRuntime().exec(shell, null, null);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

private void LoadView() {
	
    
    
    
    


				
	
		
	Switch al = mainView.findViewById(R.id.al);
	al.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
				if (isChecked){
					Execute("/base 24","Bypass On");
				} else {
					Execute("/base 24","Bypass on");
				}
			}
		});
	

	Switch bt = mainView.findViewById(R.id.bt);
	bt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
				if (isChecked){
					Execute("/on.sh","iptable on");
				} else {
					Execute("/off.sh","iptable off");
				}
			}
		});
		
	Switch xh = mainView.findViewById(R.id.xh);
	xh.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
				if (isChecked){
					Execute("/log.sh","cleaner on");
				} else {
					Execute("/log.sh","cleaner off");
			}
			}
		});
		
	Switch Ipad = mainView.findViewById(R.id.Ipad);
	Ipad.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
				if (isChecked){
					Execute("/base 27","ipad On");
				} else {
					Execute("/base 25","ipad off");
				}
			}
		});
	
	Switch Flash = mainView.findViewById(R.id.Flash);
	Flash.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
				if (isChecked){
					Execute("/base 17","Flash On");
				} else {
					Execute("/base 18","Flash off");
				}
			}
		});
	
		/*
    SeekBar seekbar_wideview = mainView.findViewById(R.id.seekbar_wideview);
   // final TextView textview_seekbar = mainView.findViewById(R.id.textview_wideview);        
    seekbar_wideview.incrementProgressBy(10);
    seekbar_wideview.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
            @Override
            public void onProgressChanged(SeekBar p1, int progress, boolean p3) {
                progress = progress / 1;
                progress = progress * 1;
     //           textview_seekbar.setText(String.valueOf(progress));
     
     
     
            }
            @Override
            public void onStartTrackingTouch(SeekBar p1) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar p1) {
                int progress = p1.getProgress();
                progress = progress / 1;
                progress = progress * 1;
                if (progress == 0) {                  
                Execute("/W 1","Wide Skala 0%");
                } else if (progress == 1) {
                Execute("/W ","Wide Skala 20%");
                } else if (progress == 2) {
                Execute("/W 3","Wide Skala 30%");
                } else if (progress == 3) {
                Execute("/W 4","Wide Skala 40%");
                } else if (progress == 4) {
                Execute("/W 5","Wide Skala 50%");
                } else if (progress == 5) {
                Execute("/W 6","Wide Skala 60%");
                } else if (progress == 6) {
                Execute("/W 7","Wide Skala 70%");
                } else if (progress == 7) {
                Execute("/W 8","Wide Skala 80%");
                } else if (progress == 8) {
                Execute("/W 9","Wide Skala 90%");
                } else if (progress == 9) {
                Execute("/W 10%","Wide Skala 100%");
                } else if (progress == 10){
                Execute("/W 11","Wide Skala 110%");
                } else if (progress == 11){
                Execute("/W 12","Wide Skala 120%");
                } else if (progress == 12){
                Execute("/W 13","Wide Skala 130%");
                } else if (progress == 13){
                Execute("/W 14","Wide Skala 140%");
                } else if (progress == 14){
                Execute("/W 15","Wide Skala 150%");
                    
                
                
                }
            }
			
            
        });
    seekbar_wideview.setProgress(0);
  //  textview_seekbar.setText(String.valueOf(seekbar_wideview.getProgress()));
    
        
  
  */
    
			
      }
      
     
      
      

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (mainView != null){
			windowManager.removeView(mainView);
		}
	}
}
