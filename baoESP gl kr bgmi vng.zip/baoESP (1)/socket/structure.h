#include "socket.h"
#include <string>
#define maxLingCount 100
#define maxvehicleCount 50
using namespace std;


enum Mode
{
	InitMode = 1,
	ESPMode = 2,
	HackMode = 3,
	StopMode = 4,
};

struct Fengling
{
	bool BulletMode,BulletModePlayer,BulletModeSingle;
	int ScreenWidth;
	int ScreenHeight;
	int aimingRange;
	int aimbotmode = 1;
	int FlyingSleep;
	int screenWidth = -1,screenHeight = -1;
};

struct SetFeng
{
	int mode;
	int type;
	int px = -1;
	int py = -1;
	int Game;
	int GameBit;
};

struct ItemData {
    char ItemName[50];
    float x;
	float y;
	float w;
    float Distance;
};

struct LingData
{
	float x;
	float y;
	float w;
	float h;
	int Distance;
	int Health;
	int isBot;
	int State;
	int TeamID;
	float Unhealthy;
	char PlayerName[100];
	Vector2A Radar;
	Vector2A Head;
	Vector2A Chest;
	Vector2A Pelvis;
	Vector2A Left_Shoulder;
	Vector2A Right_Shoulder;
	Vector2A Left_Elbow;
	Vector2A Right_Elbow;
	Vector2A Left_Wrist;
	Vector2A Right_Wrist;
	Vector2A Left_Thigh;
	Vector2A Right_Thigh;
	Vector2A Left_Knee;
	Vector2A Right_Knee;
	Vector2A Left_Ankle;
	Vector2A Right_Ankle;
	int BulletPlayer;
	int RadarX,RadarY;
	int GunBullets;
};

struct Resling {
	bool open;//绘图开关
	int LingCount;				// 数据遍历
	LingData Data[maxLingCount];
	int PlayerCount,BotCount;
};
