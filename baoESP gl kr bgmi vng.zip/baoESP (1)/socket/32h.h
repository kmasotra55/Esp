#include <stdio.h>
#include <conio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/socket.h>
#include <malloc.h>
#include <math.h>
#include <thread>
#include <iostream>
#include <sys/stat.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <iostream>
#include <locale>
#include <string>
#include <codecvt>
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/uio.h>
#include <linux/input.h>

#if defined(__arm__)
int process_vm_readv_syscall = 376;
int process_vm_writev_syscall = 377;
#elif defined(__aarch64__)
int process_vm_readv_syscall = 270;
int process_vm_writev_syscall = 271;
#elif defined(__i386__)
int process_vm_readv_syscall = 347;
int process_vm_writev_syscall = 348;
#else
int process_vm_readv_syscall = 310;
int process_vm_writev_syscall = 311;
#endif

//坐标计算宏
#define MaxPlayerCount 30
#define MaxVehicleCount 20
#define MaxItemsCount 20
#define MaxGrenadeCount 20
#define MaxAirBoxCount 20

	// 文字转码
#ifndef __UTF_H__
#define __UTF_H__
#define FALSE 0
#define TRUE 1
#define halfShift 10
#define UNI_SUR_HIGH_START (UTF32)0xD800
#define UNI_SUR_HIGH_END (UTF32)0xDBFF
#define UNI_SUR_LOW_START (UTF32)0xDC00
#define UNI_SUR_LOW_END (UTF32)0xDFFF
	// Some fundamental constants
#define UNI_REPLACEMENT_CHAR (UTF32)0x0000FFFD
#define UNI_MAX_BMP (UTF32)0x0000FFFF
#define UNI_MAX_UTF16 (UTF32)0x0010FFFF
#define UNI_MAX_UTF32 (UTF32)0x7FFFFFFF
#define UNI_MAX_LEGAL_UTF32 (UTF32)0x0010FFFF
typedef unsigned char boolean;
typedef unsigned int CharType;
typedef char UTF8;
typedef unsigned short UTF16;
typedef unsigned int UTF32;

//公共变量区域
int ipid,handle,scwq;;
float matrix[50], px, py, angle;
int GameBit;
int FingerMax = 2;
float SlideRanges = 200.0f;
float SlideX = 0.0f;
float SlideY = 0.0f;

static const UTF32 halfMask = 0x3FFUL;
static const UTF32 halfBase = 0x0010000UL;
static const UTF8 firstByteMark[7] = { 0x00, 0x00, 0xC0, 0xE0, 0xF0, 0xF8, 0xFC };
static const UTF32 offsetsFromUTF8[6] =
	{ 0x00000000UL, 0x00003080UL, 0x000E2080UL, 0x03C82080UL, 0xFA082080UL, 0x82082080UL };
static const char trailingBytesForUTF8[256] = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5
};

typedef enum
{
	strictConversion = 0,
	lenientConversion
}
ConversionFlags;
typedef enum
{
	conversionOK,				// conversion successful
	sourceExhausted,			// partial character in source,but hit end
	targetExhausted,			// insuff. room in target for conversion
	sourceIllegal,				// source sequence is illegal/malformed
	conversionFailed
}
ConversionResult;
#endif


/*下面是函数区域*/

//Open_Memory Function
int Open_Memory()
{
	char lj[64];
	if(ipid == -1)
	{exit(1);}
	sprintf(lj, "/proc/%d/mem", ipid);
	handle = open(lj, O_RDWR);
	if (handle == 0)
	{
		puts("获取mem失败!");
		exit(1);
	}

}




ssize_t process_v(pid_t __pid, const struct iovec* __local_iov, unsigned long __local_iov_count,
                  const struct iovec* __remote_iov, unsigned long __remote_iov_count, unsigned long __flags, bool iswrite) {
    return syscall((iswrite ? process_vm_writev_syscall : process_vm_readv_syscall), __pid, __local_iov, __local_iov_count, __remote_iov, __remote_iov_count, __flags);
}

bool pvm(int ipid , void* address, void* buffer, size_t size, bool iswrite) {
    struct iovec local[1];
    struct iovec remote[1];

    local[0].iov_base = buffer;
    local[0].iov_len = size;
    remote[0].iov_base = address;
    remote[0].iov_len = size;

    if (ipid < 0) {
        return false;
    }

    ssize_t bytes = process_v(ipid, local, 1, remote, 1, 0, iswrite);
    return bytes == size;
}
//bool vm_readv(long int address, void *buffer, size_t size) {
//	return pvm(ipid, reinterpret_cast<void *>(address), buffer, size, false);
//}

/* 写内存 */
/*
bool vm_writev(long int address, void *buffer, size_t size) {
	return pvm(ipid, reinterpret_cast<void *>(address), buffer, size, true);
}
*/

size_t vm_writev(long address, void *buffer, size_t size)
{
	struct iovec iov_WriteBuffer, iov_WriteOffset;
	iov_WriteBuffer.iov_base = buffer;
	iov_WriteBuffer.iov_len = size;
	iov_WriteOffset.iov_base = (void *)address;
	iov_WriteOffset.iov_len = size;
	return syscall(SYS_process_vm_writev, ipid, &iov_WriteBuffer, 1, &iov_WriteOffset, 1, 0);
}


size_t vm_readv(long address, void *buffer, size_t size)
{
	struct iovec iov_ReadBuffer, iov_ReadOffset;
	iov_ReadBuffer.iov_base = buffer;
	iov_ReadBuffer.iov_len = size;
	iov_ReadOffset.iov_base = (void *)address;
	iov_ReadOffset.iov_len = size;
	return syscall(SYS_process_vm_readv, ipid, &iov_ReadBuffer, 1, &iov_ReadOffset, 1, 0);
}



int Utf16_To_Utf8(const UTF16 * sourceStart, UTF8 * targetStart, size_t outLen,
				  ConversionFlags flags)
{
	int result = 0;
	const UTF16 *source = sourceStart;
	UTF8 *target = targetStart;
	UTF8 *targetEnd = targetStart + outLen;
	if ((NULL == source) || (NULL == targetStart))
	{
		// printf("ERR,Utf16_To_Utf8:source=%p,targetStart=%p\n",source,targetStart);
		return conversionFailed;
	}

	while (*source)
	{
		UTF32 ch;
		unsigned short bytesToWrite = 0;
		const UTF32 byteMask = 0xBF;
		const UTF32 byteMark = 0x80;
		const UTF16 *oldSource = source;	// In case we have to back up
		// because of target overflow.
		ch = *source++;
		// If we have a surrogate pair,convert to UTF32 first.
		if (ch >= UNI_SUR_HIGH_START && ch <= UNI_SUR_HIGH_END)
		{
			// If the 16 bits following the high surrogate are in the source
			// buffer...
			if (*source)
			{
				UTF32 ch2 = *source;
				// If it's a low surrogate,convert to UTF32.
				if (ch2 >= UNI_SUR_LOW_START && ch2 <= UNI_SUR_LOW_END)
				{
					ch = ((ch - UNI_SUR_HIGH_START) << halfShift) + (ch2 - UNI_SUR_LOW_START) +
						halfBase;
					++source;
				}
				else if (flags == strictConversion)
				{				// it's an unpaired high surrogate
					--source;	// return to the illegal value itself
					result = sourceIllegal;
					break;
				}
			}
			else
			{					// We don't have the 16 bits following the
				// high surrogate.
				--source;		// return to the high surrogate
				result = sourceExhausted;
				break;
			}
		}
		else if (flags == strictConversion)
		{
			// UTF-16 surrogate values are illegal in UTF-32
			if (ch >= UNI_SUR_LOW_START && ch <= UNI_SUR_LOW_END)
			{
				--source;		// return to the illegal value itself
				result = sourceIllegal;
				break;
			}
		}
		// Figure out how many bytes the result will require
		if (ch < (UTF32) 0x80)
		{
			bytesToWrite = 1;
		}
		else if (ch < (UTF32) 0x800)
		{
			bytesToWrite = 2;
		}
		else if (ch < (UTF32) 0x10000)
		{
			bytesToWrite = 3;
		}
		else if (ch < (UTF32) 0x110000)
		{
			bytesToWrite = 4;
		}
		else
		{
			bytesToWrite = 3;
			ch = UNI_REPLACEMENT_CHAR;
		}
		target += bytesToWrite;
		if (target > targetEnd)
		{
			source = oldSource;	// Back up source pointer!
			target -= bytesToWrite;
			result = targetExhausted;
			break;
		}
		switch (bytesToWrite)
		{						// note: everything falls through.
		case 4:
			*--target = (UTF8) ((ch | byteMark) & byteMask);
			ch >>= 6;
		case 3:
			*--target = (UTF8) ((ch | byteMark) & byteMask);
			ch >>= 6;
		case 2:
			*--target = (UTF8) ((ch | byteMark) & byteMask);
			ch >>= 6;
		case 1:
			*--target = (UTF8) (ch | firstByteMark[bytesToWrite]);
		}
		target += bytesToWrite;
	}
	return result;
}

typedef char PACKAGENAME;
int getPID(const char *packageName)
{
	int id = -1;
	DIR *dir;
	FILE *fp;
	char filename[64];
	char cmdline[64];
	struct dirent *entry;
	dir = opendir("/proc");
	while ((entry = readdir(dir)) != NULL)
	{
		id = atoi(entry->d_name);
		if (id != 0)
		{
			sprintf(filename, "/proc/%d/cmdline", id);
			fp = fopen(filename, "r");
			if (fp)
			{
				fgets(cmdline, sizeof(cmdline), fp);
				fclose(fp);
				if (strcmp(packageName, cmdline) == 0)
				{
					return id;
				}
			}
		}
	}
	closedir(dir);
	return -1;
}

long int get_module_base(int pid, const char *module_name)
{
	FILE *fp;
	long addr = 0;
	char *pch;
	char filename[64];
	char line[1024];
	snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
	fp = fopen(filename, "r");
	if (fp != NULL)
	{
		while (fgets(line, sizeof(line), fp))
		{
			if (strstr(line, module_name))
			{
				pch = strtok(line, "-");
				addr = strtoul(pch, NULL, 16);
				if (addr == 0x8000)
					addr = 0;
				break;
			}
		}
		fclose(fp);
	}
	return addr;
}

/* 读整数型内存 */
int getDword(long int addr) {
	long int var[1] = { 0 };
	vm_readv(addr, var, 4);
	return var[0];
}

/* 读浮点型内存 */
float getFloat(long int addr) {
	float var[1] = { 0 };
	vm_readv(addr, var, 4);
	return var[0];
}

long int getZZ(long int addr)
{
	long int var[1] = { 0 };
	vm_readv(addr, var, GameBit);
	return var[0];
}

long int getword(long int addr)
{
	long int var[1] = { 0 };
	vm_readv(addr, var, 2);
	return var[0];
}


void WriteDword(unsigned int addr, int data) 
{
   vm_writev(addr, &data, 4); 
}

// 写入F类内存
void WriteFloat(unsigned int addr, float data)
{
	vm_writev(addr, &data, 4);
}




// 获取名字

//using namespace std;



struct Vector2A {
	float X;
	float Y;

	Vector2A() {
		this->X = 0;
		this->Y = 0;
	}

	Vector2A(float x, float y) {
		this->X = x;
		this->Y = y;
	}
};

struct Vector3A {
	float X;
	float Y;
	float Z;

	Vector3A() {
		this->X = 0;
		this->Y = 0;
		this->Z = 0;
	}

	Vector3A(float x, float y, float z) {
		this->X = x;
		this->Y = y;
		this->Z = z;
	}

};

struct Vector4A {
	float x;
	float y;
	float h;
	float w;

	Vector4A() {
		this->x = 0;
		this->y = 0;
		this->h = 0;
		this->w = 0;
	}


	Vector4A (float x, float y, float h, float w) {
		this->x = x;
		this->y = y;
		this->h = h;
		this->w = w;
	}
};



struct FMatrix {
	float M[4][4];
};

struct Quat {
	float X;
	float Y;
	float Z;
	float W;
};


struct FTransform {
	Quat Rotation;
	Vector3A Translation;
	float chunk;
	Vector3A Scale3D;
};



struct MAPS1 {
	long int addr;
	long int taddr;
	int type;
	struct MAPS1 *next;
};

typedef struct MAPS1 *PMAPS1;

#define LEN sizeof(struct MAPS)


/* ------ 相关数据计算 ------ */
/*人物骨骼*/
FMatrix TransformToMatrix(FTransform transform) {
	FMatrix matrix;
	matrix.M[3][0] = transform.Translation.X;
	matrix.M[3][1] = transform.Translation.Y;
	matrix.M[3][2] = transform.Translation.Z;
	float x2 = transform.Rotation.X + transform.Rotation.X;
	float y2 = transform.Rotation.Y + transform.Rotation.Y;
	float z2 = transform.Rotation.Z + transform.Rotation.Z;
	float xx2 = transform.Rotation.X * x2;
	float yy2 = transform.Rotation.Y * y2;
	float zz2 = transform.Rotation.Z * z2;
	matrix.M[0][0] = (1 - (yy2 + zz2)) * transform.Scale3D.X;
	matrix.M[1][1] = (1 - (xx2 + zz2)) * transform.Scale3D.Y;
	matrix.M[2][2] = (1 - (xx2 + yy2)) * transform.Scale3D.Z;
	float yz2 = transform.Rotation.Y * z2;
	float wx2 = transform.Rotation.W * x2;
	matrix.M[2][1] = (yz2 - wx2) * transform.Scale3D.Z;
	matrix.M[1][2] = (yz2 + wx2) * transform.Scale3D.Y;
	float xy2 = transform.Rotation.X * y2;
	float wz2 = transform.Rotation.W * z2;
	matrix.M[1][0] = (xy2 - wz2) * transform.Scale3D.Y;
	matrix.M[0][1] = (xy2 + wz2) * transform.Scale3D.X;
	float xz2 = transform.Rotation.X * z2;
	float wy2 = transform.Rotation.W * y2;
	matrix.M[2][0] = (xz2 + wy2) * transform.Scale3D.Z;
	matrix.M[0][2] = (xz2 - wy2) * transform.Scale3D.X;
	matrix.M[0][3] = 0;
	matrix.M[1][3] = 0;
	matrix.M[2][3] = 0;
	matrix.M[3][3] = 1;
	return matrix;
}


/* 计算3D坐标距离 */
float getDistance(Vector3A mxyz, Vector3A exyz)
{
	float X = mxyz.X - exyz.X;
	float Y = mxyz.Y - exyz.Y;
	float Z = mxyz.Z - exyz.Z;
	return (sqrt((X) * (X) + (Y) * (Y) + (Z) * (Z)) / 100) - 2;
}

Vector2A WorldToScreen(Vector3A obj , float matrix[16]) {
	float ViewW = matrix[3] * obj.X + matrix[7] * obj.Y + matrix[11] * obj.Z + matrix[15];
	float x = px + (matrix[0] * obj.X + matrix[4] * obj.Y + matrix[8] * obj.Z + matrix[12]) / ViewW * px;
	float y = py - (matrix[1] * obj.X + matrix[5] * obj.Y + matrix[9] * obj.Z + matrix[13]) / ViewW * py;
	return Vector2A(x, y);
}

#define PI 3.141592653589793238
double HX = 180 / PI;

Vector2A getPointing(Vector3A xyz, Vector3A camera)
{
	Vector2A PointingAngle;
	float zbcx = xyz.X - camera.X;
	float zbcy = xyz.Y - camera.Y;
	float zbcz = xyz.Z - camera.Z;
	double pfg = sqrt((zbcx * zbcx) + (zbcy * zbcy));
	PointingAngle.X = (float)atan2(zbcy, zbcx) * HX;
	PointingAngle.Y = (float)atan2(zbcz, pfg) * HX;
	return PointingAngle;
}

Vector2A WorldToScreen2(Vector3A obj , float matrix[16]) {
	float ViewW = matrix[3] * obj.X + matrix[7] * obj.Y + matrix[11] * obj.Z + matrix[15];
	if (ViewW < 0.01) {
		return Vector2A(3100, 3100);
	}
	float x = px + (matrix[0] * obj.X + matrix[4] * obj.Y + matrix[8] * obj.Z + matrix[12]) / ViewW * px;
	float y = py - (matrix[1] * obj.X + matrix[5] * obj.Y + matrix[9] * obj.Z + matrix[13]) / ViewW * py;
	return Vector2A(x,y);
}

Vector3A MarixToVector(FMatrix matrix) {
	return Vector3A(matrix.M[3][0], matrix.M[3][1], matrix.M[3][2]);
}

FMatrix MatrixMulti(FMatrix m1, FMatrix m2) {
	FMatrix matrix = FMatrix();
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			for (int k = 0; k < 4; k++) {
				matrix.M[i][j] += m1.M[i][k] * m2.M[k][j];
			}
		}
	}
	return matrix;
}

struct D3DXMATRIX
{
	float _11;
	float _12;
	float _13;
	float _14;
	float _21;
	float _22;
	float _23;
	float _24;
	float _31;
	float _32;
	float _33;
	float _34;
	float _41;
	float _42;
	float _43;
	float _44;
};

FTransform getBone(long int addr) {
	FTransform transform;
	vm_readv(addr, &transform, 4 * 11);
	return transform;
}

D3DXMATRIX ToMatrixWithScale(Quat Rotation, Vector3A Translation, Vector3A Scale3D)
{
	D3DXMATRIX M;
	float X2, Y2, Z2, xX2, Yy2, Zz2, Zy2, Wx2, Xy2, Wz2, Zx2, Wy2;
	M._41 = Translation.X;
	M._42 = Translation.Y;
	M._43 = Translation.Z;
	X2 = Rotation.X + Rotation.X;
	Y2 = Rotation.Y + Rotation.Y;
	Z2 = Rotation.Z + Rotation.Z;
	xX2 = Rotation.X * X2;
	Yy2 = Rotation.Y * Y2;
	Zz2 = Rotation.Z * Z2;
	M._11 = (1 - (Yy2 + Zz2)) * Scale3D.X;
	M._22 = (1 - (xX2 + Zz2)) * Scale3D.Y;
	M._33 = (1 - (xX2 + Yy2)) * Scale3D.Z;
	Zy2 = Rotation.Y * Z2;
	Wx2 = Rotation.W * X2;
	M._32 = (Zy2 - Wx2) * Scale3D.Z;
	M._23 = (Zy2 + Wx2) * Scale3D.Y;
	Xy2 = Rotation.X * Y2;
	Wz2 = Rotation.W * Z2;
	M._21 = (Xy2 - Wz2) * Scale3D.Y;
	M._12 = (Xy2 + Wz2) * Scale3D.X;
	Zx2 = Rotation.X * Z2;
	Wy2 = Rotation.W * Y2;
	M._31 = (Zx2 + Wy2) * Scale3D.Z;
	M._13 = (Zx2 - Wy2) * Scale3D.X;
	M._14 = 0;
	M._24 = 0;
	M._34 = 0;
	M._44 = 1;
	return M;
}



Vector3A D3dMatrixMultiply(D3DXMATRIX bonematrix, D3DXMATRIX actormatrix)
{
	Vector3A result;
	result.X =
		bonematrix._41 * actormatrix._11 + bonematrix._42 * actormatrix._21 +
		bonematrix._43 * actormatrix._31 + bonematrix._44 * actormatrix._41;
	result.Y =
		bonematrix._41 * actormatrix._12 + bonematrix._42 * actormatrix._22 +
		bonematrix._43 * actormatrix._32 + bonematrix._44 * actormatrix._42;
	result.Z =
		bonematrix._41 * actormatrix._13 + bonematrix._42 * actormatrix._23 +
		bonematrix._43 * actormatrix._33 + bonematrix._44 * actormatrix._43;
	return result;
}


FTransform ReadFTransform(long int address)
{
	FTransform Result;
	Result.Rotation.X = getFloat(address);	// Rotation_X 
	Result.Rotation.Y = getFloat(address + 4);	// Rotation_y
	Result.Rotation.Z = getFloat(address + 8);	// Rotation_z
	Result.Rotation.W = getFloat(address + 12);	// Rotation_w
	Result.Translation.X = getFloat(address + 16);	// /Translation_X
	Result.Translation.Y = getFloat(address + 20);	// Translation_y
	Result.Translation.Z = getFloat(address + 24);	// Translation_z
	Result.Scale3D.X = getFloat(address + 32);;	// Scale_X
	Result.Scale3D.Y = getFloat(address + 36);;	// Scale_y
	Result.Scale3D.Z = getFloat(address + 40);;	// Scale_z
	return Result;
}

Vector3A getBoneXYZ(long int humanAddr, long int boneAddr, int Part)
{
	// 获取Bone数据
	FTransform Bone = ReadFTransform(boneAddr + Part * 48);
	// 获取Actor数据
	FTransform Actor = ReadFTransform(humanAddr);
	D3DXMATRIX Bone_Matrix = ToMatrixWithScale(Bone.Rotation, Bone.Translation, Bone.Scale3D);
	D3DXMATRIX Component_ToWorld_Matrix =
		ToMatrixWithScale(Actor.Rotation, Actor.Translation, Actor.Scale3D);
	Vector3A result = D3dMatrixMultiply(Bone_Matrix, Component_ToWorld_Matrix);
	return result;
}

void BypassGameSafe() 
{ 
system("echo 128 > /proc/sys/fs/inotify/max_user_instances");
system("echo 0 > /proc/sys/fs/inotify/max_user_watches");
system("echo 16384 > /proc/sys/fs/inotify/max_queued_events");
}

void getCharacterName(UTF8 * transcoding, long int addr, int NameAddr)	// 传入指针
{
	int classname;
	int m = 0;
	UTF8 buf88[256] = "";
	long int namepy = getZZ(addr + NameAddr);
	UTF16 buf16[34] = {
		0
	};
	int hex[2] = {
		0
	};
	for (int i = 0; i < 4; i++)
	{
		classname = getZZ(namepy + i * 4);
		hex[0] = (classname & 0xfffff000) >> 16;
		hex[1] = classname & 0xffff;
		buf16[m] = hex[1];
		buf16[m + 1] = hex[0];
		m += 2;
	}
	Utf16_To_Utf8(buf16, buf88, sizeof(buf88), strictConversion);
	sprintf(transcoding, "%s", buf88);
}

int GetEventCount()
{
	DIR *dir = opendir("/dev/input/");
	dirent *ptr = NULL;
	int count = 0;
	while ((ptr = readdir(dir)) != NULL)
	{
		if (strstr(ptr->d_name, "event"))
			count++;
	}
	// printf("count:%d\n",count);
	return count;
}


int GetEventId_2()
{
	int EventCount = GetEventCount();
	int *fdArray = (int *)malloc(EventCount * 4 + 4);
	int result;

	for (int i = 0; i < EventCount; i++)
	{
		char temp[128];
		sprintf(temp, "/dev/input/event%d", i);
		fdArray[i] = open(temp, O_RDWR | O_NONBLOCK);
	}
	puts("由于您部分原因，设备需要校准，请点击屏幕完成校准");

	int k = 0;
	input_event ev;
	while (1)
	{
		for (int i = 0; i < EventCount; i++)
		{
			memset(&ev, 0, sizeof(ev));
			read(fdArray[i], &ev, sizeof(ev));
			if (ev.type == EV_ABS)
			{
				printf("id:%d 校准成功\n", i);
				free(fdArray);
				return i;
			}
		}
		usleep(100);
	}
}

void TouchDown(int fd, int x, int y)
{
	struct input_event event;

	// init
	event.type = EV_KEY;
	event.code = BTN_TOUCH;
	gettimeofday(&event.time, 0);
	event.value = KEY_DOWN;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_KEY;
	event.code = BTN_TOOL_FINGER;
	gettimeofday(&event.time, 0);
	event.value = KEY_DOWN;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_SYN;
	event.code = SYN_REPORT;
	gettimeofday(&event.time, 0);
	event.value = 0;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_ABS;
	event.code = ABS_MT_SLOT;
	gettimeofday(&event.time, 0);
	event.value = FingerMax;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_ABS;
	event.code = ABS_MT_TRACKING_ID;
	gettimeofday(&event.time, 0);
	event.value = 123;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_ABS;
	event.code = ABS_MT_POSITION_X;
	gettimeofday(&event.time, 0);
	event.value = x;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_ABS;
	event.code = ABS_MT_POSITION_Y;
	gettimeofday(&event.time, 0);
	event.value = y;
	write(fd, &event, sizeof(struct input_event));
	
	event.type = EV_SYN;
	event.code = SYN_REPORT;
	gettimeofday(&event.time, 0);
	event.value = 0;
	write(fd, &event, sizeof(struct input_event));
	// init
}

void TouchMove(int fd, int x, int y)
{
	if (x >= SlideX+SlideRanges || x <= SlideX-SlideRanges || y >= SlideY+SlideRanges || y <= SlideY-SlideRanges)
	{
		return;
	}
	
	struct input_event event;
	
	event.type = EV_ABS;
	event.code = ABS_MT_SLOT;
	gettimeofday(&event.time, 0);
	event.value = FingerMax;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_ABS;
	event.code = ABS_MT_TRACKING_ID;
	gettimeofday(&event.time, 0);
	event.value = 123;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_KEY;
	event.code = BTN_TOUCH;
	gettimeofday(&event.time, 0);
	event.value = KEY_DOWN;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_ABS;
	event.code = ABS_MT_POSITION_X;
	gettimeofday(&event.time, 0);
	event.value = x;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_ABS;
	event.code = ABS_MT_POSITION_Y;
	gettimeofday(&event.time, 0);
	event.value = y;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_SYN;
	event.code = SYN_REPORT;
	gettimeofday(&event.time, 0);
	event.value = 0;
	write(fd, &event, sizeof(struct input_event));
}

void TouchUp(int fd)
{
	struct input_event event;

	// for (int i = 0; i < FingerMax+1; i++)
	// {
	event.type = EV_ABS;
	event.code = ABS_MT_SLOT;
	gettimeofday(&event.time, 0);
	event.value = FingerMax;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_ABS;
	event.code = ABS_MT_TRACKING_ID;
	gettimeofday(&event.time, 0);
	event.value = 0xFFFFFFFF;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_SYN;
	event.code = SYN_REPORT;
	gettimeofday(&event.time, 0);
	event.value = 0;
	write(fd, &event, sizeof(struct input_event));
	// }

	event.type = EV_KEY;
	event.code = BTN_TOUCH;
	gettimeofday(&event.time, 0);
	event.value = KEY_UP;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_KEY;
	event.code = BTN_TOOL_FINGER;
	gettimeofday(&event.time, 0);
	event.value = KEY_UP;
	write(fd, &event, sizeof(struct input_event));

	event.type = EV_SYN;
	event.code = SYN_REPORT;
	gettimeofday(&event.time, 0);
	event.value = 0;
	write(fd, &event, sizeof(struct input_event));
}

int getTouchEventNum()
{
	char name[64];
	char buf[256] = { 0 };
	int fd = 0;
	int i;
	for (i = 0; i < 32; i++)
	{
		sprintf(name, "/dev/input/event%d", i);
		if ((fd = open(name, O_RDONLY, 0)) >= 0)
		{
			ioctl(fd, EVIOCGPHYS(sizeof(buf)), buf);
			//puts(buf);
			if (strstr(buf, "fts") != 0 || strstr(buf, "touch") != 0)
			{
				close(fd);
				return i;
			}
			close(fd);
		}
	}
	return -1;
}