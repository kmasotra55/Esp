#include "32h.h"
#include "structure.h"
float MatrixValue[16] = { 0 }; 
int MatrixAddr,UwroldAddr,XBAddr,wzzbAddr,
objectAddr,MeshOffsetAddr,dzAddr,kjAddr,khAddr,
zmAddrone,zmAddrtwo,zdAddr,ftAddr,
MatrixAddrtwo,MatrixAddrthree,oneselfAddrone,
oneselfAddrtwo,UleveAddr,arrayaddrAddr,countAddr,
teamAddr,XYZAddr,hpAddr,zdAddrtwo,NameAddr,
aiAddr,MeshAddressAddr,BoneAddr,CameraAddr,
angleAddr,dxAddr,hpMaxAddr,fb;
bool TGMPMode,fbsucces;

void offical()
{
	MatrixAddr = 0x2F9F18;
	MatrixAddrtwo = 0x7C;
	MatrixAddrthree = 0x510;
	UwroldAddr = 0x2AAA4;
	oneselfAddrone = 0x8;
	oneselfAddrtwo = 0x54;
	UleveAddr = 0x18;
	arrayaddrAddr = 0x70;
	countAddr = 0x74;
	teamAddr = 0x69C;
	XYZAddr = 0x150;
	XBAddr = 0x775D000;
	wzzbAddr = 0x1B00;
	objectAddr = 0x34C; //164
	MeshOffsetAddr = 0x344;
	dzAddr = 0xB10;
	kjAddr = 0x304;
	khAddr = 0xFA8;
	zmAddrone = 0x320;
	zmAddrtwo = 0x368;
	zdAddr = 0x1AB8;
	ftAddr = 0x13D0;
	hpAddr = 0x9A4;
	zdAddrtwo = 0xAB8;
	NameAddr = 0x668;
	aiAddr = 0x714;
	MeshAddressAddr = 0x140;
	BoneAddr = 0x5E8;
	CameraAddr = 0x380;
	angleAddr = 0x18B8;
	dxAddr = 0x1234;
	hpMaxAddr = 0x4;
}

void beta()
{
	MatrixAddr = 0x2F9C18;
	MatrixAddrtwo = 0x7C;
	MatrixAddrthree = 0x510;
	UwroldAddr = 0x2A7A4;
	oneselfAddrone = 0x8;
	oneselfAddrtwo = 0x54;
	UleveAddr = 0x18;
	arrayaddrAddr = 0x70;
	countAddr = 0x74;
	teamAddr = 0x69C;
	XYZAddr = 0x150;
	XBAddr = 0x7778000;
	wzzbAddr = 0x1B00;
	objectAddr = 0x34C; //164
	MeshOffsetAddr = 0x344;
	dzAddr = 0xB10;
	kjAddr = 0x304;
	khAddr = 0xFA8;
	zmAddrone = 0x320;
	zmAddrtwo = 0x368;
	zdAddr = 0x1AB8;
	ftAddr = 0x13D0;
	hpAddr = 0x9A4;
	zdAddrtwo = 0xAB8;
	NameAddr = 0x668;
	aiAddr = 0x714;
	MeshAddressAddr = 0x140;
	BoneAddr = 0x5E8;
	CameraAddr = 0x380;
	angleAddr = 0x18B8;
	dxAddr = 0x1234;
	hpMaxAddr = 0x4;
}

void twobeta()
{
	MatrixAddr = 0x433230;
	MatrixAddrtwo = 0xC0;
	MatrixAddrthree = 0x590;
	UwroldAddr = 0x392C0;
	oneselfAddrone = 0x10;
	oneselfAddrtwo = 0x78;
	UleveAddr = 0x20;
	arrayaddrAddr = 0xA0;
	countAddr = 0xA8;
	teamAddr = 0x8D0;
	XYZAddr = 0x1B0;
	XBAddr = 0xA532000;
	wzzbAddr = 0x2310;
	objectAddr = 0x448;
	MeshOffsetAddr = 0x438;
	dzAddr = 0xEC8;
	kjAddr = 0x3E0;
	khAddr = 0x14E8;
	zmAddrone = 0x410;
	zmAddrtwo = 0x470;
	zdAddr = 0x2298;
	ftAddr = 0x13D0;
	hpAddr = 0xCC8;
	zdAddrtwo = 0xD88;
	NameAddr = 0x888;
	aiAddr = 0x960;
	MeshAddressAddr = 0x1A0;
	BoneAddr = 0x738;
	CameraAddr = 0x460;
	angleAddr = 0x203C;
	dxAddr = 0x17E8;
	hpMaxAddr = 0x4;
}

void tgmp()
{
	MatrixAddr = 0x2F6E40;
	MatrixAddrtwo = 0x68;
	MatrixAddrthree = 0x2A0;
	UwroldAddr = 0xCC340;
	oneselfAddrone = 0xC;
	oneselfAddrtwo = 0x280;
	UleveAddr = 0x18;
	arrayaddrAddr = 0x70;
	countAddr = 0x74;
	teamAddr = 0x768;
	XYZAddr = 0x160;
	XBAddr = 0x7C65000;
	wzzbAddr = 0x9D4;
	objectAddr = 0x1E4;
	MeshOffsetAddr = 0x448;
	dzAddr = 0xB10;
	kjAddr = 0x3F0;
	khAddr = 0x1F0;
	zmAddrone = 0x40C;
	zmAddrtwo = 0x44C;
	zdAddr = 0x1FC8;
	ftAddr = 0x13D0;
	hpAddr = 0x990;
	zdAddrtwo = 0xC08;
	NameAddr = 0x718;
	aiAddr = 0x780;
	MeshAddressAddr = 0x150;
	BoneAddr = 0x588;
	CameraAddr = 0x488;
	angleAddr = 0x140;
	dxAddr = 0x99C;
	hpMaxAddr = 0x8;
	TGMPMode = true;
}

void lite()
{
	MatrixAddr = 0x1C0E5C;
	MatrixAddrtwo = 0x2AC;
	MatrixAddrthree = 0x480;
	UwroldAddr = 0x1C0870;
	oneselfAddrone = 0x30;
	UleveAddr = 0x18;
	arrayaddrAddr = 0x70;
	countAddr = 0x74;
	teamAddr = 0x620;
	XYZAddr = 0x150;
	XBAddr = 0x4E65000;
	wzzbAddr = 0x1454;
	objectAddr = 0x314;
	MeshOffsetAddr = 0x448;
	dzAddr = 0x1680;
	kjAddr = 0x3F0;
	khAddr = 0x1F0;
	zmAddrone = 0x2E8;
	zmAddrtwo = 0x44C;
	zdAddr = 0x1FC8;
	ftAddr = 0x13D0;
	hpAddr = 0x7A0;
	zdAddrtwo = 0xC08;
	NameAddr = 0x5F8;
	aiAddr = 0x688;
	MeshAddressAddr = 0x150;
	BoneAddr = 0x588;
	CameraAddr = 0x470;
	angleAddr = 0x140;
	dxAddr = 0x99C;
	hpMaxAddr = 0x4;
}

void betatgmp()
{
	MatrixAddr = 0x2F6F40;
	MatrixAddrtwo = 0x68;
	MatrixAddrthree = 0x2A0;
	UwroldAddr = 0xCC3D0;
	oneselfAddrone = 0xC;
	oneselfAddrtwo = 0x280;
	UleveAddr = 0x18;
	arrayaddrAddr = 0x70;
	countAddr = 0x74;
	teamAddr = 0x768;
	XYZAddr = 0x160;
	XBAddr = 0x7C7C000;
	wzzbAddr = 0x9D4;
	objectAddr = 0x1E4;
	MeshOffsetAddr = 0x448;
	dzAddr = 0xB10;
	kjAddr = 0x3F0;
	khAddr = 0x1F0;
	zmAddrone = 0x40C;
	zmAddrtwo = 0x44C;
	zdAddr = 0x1FC8;
	ftAddr = 0x13D0;
	hpAddr = 0x990;
	zdAddrtwo = 0xC08;
	NameAddr = 0x718;
	aiAddr = 0x780;
	MeshAddressAddr = 0x150;
	BoneAddr = 0x588;
	CameraAddr = 0x488;
	angleAddr = 0x140;
	dxAddr = 0x99C;
	hpMaxAddr = 0x8;
	TGMPMode = true;
}
int main(int argc, char **argv)
{
	
	if (getPID("com.baoad.ESP") == -1)	//验证这个文件是否存在
    {
      //printf("验证");
      exit(1);
    }

	puts("程序开始");
	//多进程
	SetFeng ng{};

	if (!Create())
	{
		perror("创建失败");
		return 0;
	}
	if (!Connect())
	{
		perror("连接失败");
		return 0;
	}

	receive((void *)&ng);
	GameBit = ng.GameBit;
	
	
//	printf("%d",GameBit);
	
	Fengling fengling{};
	Resling resling{};
	
	px = ng.px / 2.0;
	py = ng.py / 2.0;
	if (py > px)				// 如果py大于了px，那么py就是屏幕高度了列如2340
	{
		py =  ng.px / 2.0;
		px = ng.py / 2.0;
	}
	
	if (ng.GameBit == 4)
	{
		if (ng.Game == 1)
		{
			ipid = getPID("com.tencent.ig");
			offical();
		}
		else if (ng.Game == 2)
		{
			ipid = getPID("com.vng.pubgmobile");
			offical();
		}
		else if (ng.Game == 3)
		{
			ipid = getPID("com.pubg.krmobile");
			offical();
		}
		else if (ng.Game == 4)
		{
			ipid = getPID("com.rekoo.pubgm");
			offical();
		}
		else if (ng.Game == 5)
		{
			ipid = getPID("com.pubg.imobile");
			offical();
		}
		else if (ng.Game == 6)
		{
			ipid = getPID("com.tencent.igce");
			beta();
		}
		else if (ng.Game == 7)
		{
			ipid = getPID("com.tencent.tmgp.pubgmhd");
			tgmp();
		}
		else if (ng.Game == 8)
		{
			ipid = getPID("com.tencent.tmgp.projectg");
			betatgmp();
		}
	}
	else if (ng.GameBit == 8)
	{
		if (ng.Game == 6)
		{
			ipid = getPID("com.tencent.igce");
			twobeta();
		}
	}
	puts("开始基址遍历\n");
	char mname[] = "libUE4.so";	// libUE4模块
	long int libbase = get_module_base(ipid, mname);//获取libUE4入口模块地址
	
	while ((receive((void *)&fengling) > 0))
	{
		resling.open = false;	// 绘图开关
		resling.LingCount = 0;	// 遍历数据
		resling.PlayerCount = 0;
		resling.BotCount = 0;
        long int Matrix = getZZ(getZZ(libbase + MatrixAddr + XBAddr) + MatrixAddrtwo) + MatrixAddrthree;	// 游戏矩阵
		long int Uworld = getZZ(libbase + UwroldAddr + XBAddr);//游戏世界
		long int oneself = getZZ(getZZ(Uworld + oneselfAddrone) + oneselfAddrtwo);//自身结构
        long int Uleve = getZZ(oneself + UleveAddr);// Uleve
        long int arrayaddr = getZZ(Uleve + arrayaddrAddr);	// 对象阵列
    	long int count = getDword(Uleve + countAddr);	// 遍历数量
        long int team = getDword(oneself + teamAddr);	// 自身队伍编号
        long int Temporary = 0;//临时对象
        Vector2A HeadBone;//临时对象
        float AimDistance = 1024;//自瞄最大距离
    	memset(MatrixValue, 0, 16);//初始化矩阵数组
    	vm_readv(Matrix, MatrixValue, 4 * 16);	// 矩阵指针
		//	printf("数量=%d\n", count);

		for (int i = 0; i < 16; i++)
		{
			float matrixaddr = getFloat(Matrix + i * 4);
			matrix[i] = matrixaddr;
		}
		
		for (int i = 0; i < count; i++)
		{
			LingData *Ling = &resling.Data[resling.LingCount];	// 所有数据发到*Ling
			
			long int objaddrzz = getZZ(arrayaddr + ng.GameBit * i);	// 遍历数量次数			
			// 去除物资坐标
			float wzzb = getFloat(objaddrzz + wzzbAddr);
			if (wzzb != 479.5)
			{
				continue;
			} // 不等于479.5则不输出坐标

			//人物动作
			int dz = getDword(objaddrzz + dzAddr);
			
		    if (dz == 262152 || dz == 1048576)
			{
				continue;
			}
		    
			// 队伍编号
			int zy = getDword(objaddrzz + teamAddr);

			// 去除自身和队友方框
			// 去除方框(队伍号相同则不显示)
			if (team == zy)		// 不输出自己和队友坐标
			{
				continue;
			}
            //坐标指针
			long int object = getZZ(objaddrzz + objectAddr);	// 对象地址指针
		    long int objectself = getZZ(oneself + objectAddr);
			
			// 自身坐标
			float z_x = getFloat(objectself + XYZAddr);
			float z_y = getFloat(objectself + XYZAddr + 4);
			float z_z = getFloat(objectself + XYZAddr + 8);

			// 敌人坐标
			float d_x = getFloat(object + XYZAddr);
			float d_y = getFloat(object + XYZAddr + 4);
			float d_z = getFloat(object + XYZAddr + 8);

			// 人物距离
			int m = sqrt(pow(d_x - z_x, 2) + pow(d_y - z_y, 2) + pow(d_z - z_z, 2)) * 0.01;
			if (m > 400)
			{
				continue;
			}					// 大于400米不显示

			// 计算人物矩阵
			float camear_r = matrix[3] * d_x + matrix[7] * d_y + matrix[11] * d_z + matrix[15];
			float r_x = px + (matrix[0] * d_x + matrix[4] * d_y + matrix[8] * d_z +
					  matrix[12]) / camear_r * px;
			float r_y = py - (matrix[1] * d_x + matrix[5] * d_y + matrix[9] * (d_z - 5) +
					  matrix[13]) / camear_r * py;
			float r_w = py - (matrix[1] * d_x + matrix[5] * d_y + matrix[9] * (d_z + 205) +
			         matrix[13]) / camear_r * py;

			// 健康血量
			float hp = getFloat(objaddrzz + hpAddr);
			
			// 最大血量
			float hpMax = getFloat(objaddrzz + hpAddr + hpMaxAddr);
			
			// 百分百血量
		//	float perhp  = (hp / hpMax) * 100;
			

			// 人机识别
			int ai = getDword(objaddrzz + aiAddr);
			
			//倒地血量
			int dx = getFloat(objaddrzz + dxAddr);
			
			//枪械子弹
			int zd = getDword(getZZ(objaddrzz + zdAddr) + zdAddrtwo);

			if (zy != 996 && (r_y - r_w) / 2 > 0)
			{
				/* 阵列偏移 */
				long int MeshOffset = getZZ(objaddrzz + MeshOffsetAddr); // yes
				/* 阵列指针 */
				long int MeshAddress = MeshOffset + MeshAddressAddr; // yes
				/* 骨骼指针 */
				long int BoneAddress = getZZ(MeshOffset + BoneAddr) + 0x30; //骨骼指针
				FTransform meshtrans = getBone(MeshAddress);			 // yes
				FMatrix c2wMatrix = TransformToMatrix(meshtrans);		 // yes
				// Head
				FTransform headtrans = getBone(BoneAddress + 5 * 48);
				FMatrix boneMatrix = TransformToMatrix(headtrans);
				Vector3A relLocation = MarixToVector(MatrixMulti(boneMatrix, c2wMatrix));
				relLocation.Z += 7;
				Ling->Head = WorldToScreen(relLocation, MatrixValue);
				//箱箱
				FTransform chesttrans = getBone(BoneAddress + 4 * 48);
				FMatrix boneMatrix1 = TransformToMatrix(chesttrans);
				Vector3A relLocation1 = MarixToVector(MatrixMulti(boneMatrix1, c2wMatrix));
				Ling->Chest = WorldToScreen(relLocation1, MatrixValue);
				//左肩
				FTransform lshtrans = getBone(BoneAddress + 11 * 48);
				FMatrix boneMatrix2 = TransformToMatrix(lshtrans);
				Vector3A relLocation2 = MarixToVector(MatrixMulti(boneMatrix2, c2wMatrix));
				Ling->Left_Shoulder = WorldToScreen(relLocation2, MatrixValue);
				//右肩
				FTransform rshtrans = getBone(BoneAddress + 32 * 48);
				FMatrix boneMatrix3 = TransformToMatrix(rshtrans);
				Vector3A relLocation3 = MarixToVector(MatrixMulti(boneMatrix3, c2wMatrix));
				Ling->Right_Shoulder = WorldToScreen(relLocation3, MatrixValue);
				// Left Elbow
				FTransform lelbtrans = getBone(BoneAddress + 12 * 48);
				FMatrix boneMatrix4 = TransformToMatrix(lelbtrans);
				Vector3A relLocation4 = MarixToVector(MatrixMulti(boneMatrix4, c2wMatrix));
				Ling->Left_Elbow = WorldToScreen(relLocation4, MatrixValue);
				// Right Elbow
				FTransform relbtrans = getBone(BoneAddress + 33 * 48);
				FMatrix boneMatrix5 = TransformToMatrix(relbtrans);
				Vector3A relLocation5 = MarixToVector(MatrixMulti(boneMatrix5, c2wMatrix));
				Ling->Right_Elbow = WorldToScreen(relLocation5, MatrixValue);
				// Left Wrist
				FTransform lwtrans = getBone(BoneAddress + 63 * 48);
				FMatrix boneMatrix6 = TransformToMatrix(lwtrans);
				Vector3A relLocation6 = MarixToVector(MatrixMulti(boneMatrix6, c2wMatrix));
				Ling->Left_Wrist = WorldToScreen(relLocation6, MatrixValue);
				// Right Wrist
				FTransform rwtrans = getBone(BoneAddress + 62 * 48);
				FMatrix boneMatrix7 = TransformToMatrix(rwtrans);
				Vector3A relLocation7 = MarixToVector(MatrixMulti(boneMatrix7, c2wMatrix));
				Ling->Right_Wrist = WorldToScreen(relLocation7, MatrixValue);
				// Pelvis
				FTransform Lchesttrans = getBone(BoneAddress + 1 * 48);
				FMatrix LboneMatrix1 = TransformToMatrix(Lchesttrans);
				Vector3A LrelLocation1 = MarixToVector(MatrixMulti(LboneMatrix1, c2wMatrix));
				Ling->Pelvis = WorldToScreen(LrelLocation1, MatrixValue);
				// Left thigh
				FTransform Llshtrans = getBone(BoneAddress + 52 * 48);
				FMatrix LboneMatrix2 = TransformToMatrix(Llshtrans);
				Vector3A LrelLocation2 = MarixToVector(MatrixMulti(LboneMatrix2, c2wMatrix));
				Ling->Left_Thigh = WorldToScreen(LrelLocation2, MatrixValue);
				// Right thigh
				FTransform Lrshtrans = getBone(BoneAddress + 56 * 48);
				FMatrix LboneMatrix3 = TransformToMatrix(Lrshtrans);
				Vector3A LrelLocation3 = MarixToVector(MatrixMulti(LboneMatrix3, c2wMatrix));
				Ling->Right_Thigh = WorldToScreen(LrelLocation3, MatrixValue);
				// Left Knee
				FTransform Llelbtrans = getBone(BoneAddress + 53 * 48);
				FMatrix LboneMatrix4 = TransformToMatrix(Llelbtrans);
				Vector3A LrelLocation4 = MarixToVector(MatrixMulti(LboneMatrix4, c2wMatrix));
				Ling->Left_Knee = WorldToScreen(LrelLocation4, MatrixValue);
				// Right Knee
				FTransform Lrelbtrans = getBone(BoneAddress + 57 * 48);
				FMatrix LboneMatrix5 = TransformToMatrix(Lrelbtrans);
				Vector3A LrelLocation5 = MarixToVector(MatrixMulti(LboneMatrix5, c2wMatrix));
				Ling->Right_Knee = WorldToScreen(LrelLocation5, MatrixValue);
				// Left Ankle
				FTransform Llwtrans = getBone(BoneAddress + 54 * 48);
				FMatrix LboneMatrix6 = TransformToMatrix(Llwtrans);
				Vector3A LrelLocation6 = MarixToVector(MatrixMulti(LboneMatrix6, c2wMatrix));
				Ling->Left_Ankle = WorldToScreen(LrelLocation6, MatrixValue);
				// Right Ankle
				FTransform Lrwtrans = getBone(BoneAddress + 58 * 48);
				FMatrix LboneMatrix7 = TransformToMatrix(Lrwtrans);
				Vector3A LrelLocation7 = MarixToVector(MatrixMulti(LboneMatrix7, c2wMatrix));
				Ling->Right_Ankle = WorldToScreen(LrelLocation7, MatrixValue);
			}

			Ling->x = r_x - (r_y - r_w) / 4;
			Ling->y = r_y;
			Ling->w = (r_y - r_w) / 2;
			Ling->h = r_y - r_w;
			Ling->Distance = m;//距离
			Ling->Health = (hp / hpMax) * 100;//血量
    		Ling->isBot = ai;
        	Ling->State = dz;
            Ling->TeamID = zy;
        	Ling->Unhealthy = dx;
			getCharacterName(Ling->PlayerName, objaddrzz, NameAddr);
			Ling->GunBullets = zd;
			
			if (ai == 0)
			{
				resling.PlayerCount++;
			}
			else if (ai == 1)
			{
				resling.BotCount++;
			}

			
				// 计算雷达
			angle = getFloat(oneself + angleAddr);
		    Ling->RadarX = ((z_x - d_x) / 135) * cos((angle - 90) *  3.1415 / 180) + ((z_y - d_y) / 135) * sin((angle - 90) * 3.1415 / 180);
			Ling->RadarY = -((z_x - d_x) / 135) * sin((angle - 90) * 3.1415 / 180) + ((z_y - d_y) / 135) * cos((angle - 90) * 3.1415 / 180);
			
			resling.LingCount++;
			resling.open = true;	// 绘图开

			if ((r_y - r_w) / 2 > 0)
			{
				if (fengling.BulletModePlayer == true && ai == 0 || fengling.BulletModePlayer == false)
				{
					int zxjl = sqrt(pow(r_x - px, 2) + pow(r_y - py, 2));
					Ling->BulletPlayer = zxjl;
					if (zxjl <= AimDistance && zxjl < fengling.aimingRange) //判断准心最近的敌人
					{
						AimDistance = zxjl;
						Temporary = objaddrzz;
						HeadBone = Ling->Head;
					}
				}
			}

			if (ng.GameBit == 4)
			{
				if (fengling.BulletMode == true)
				{
					Vector3A aimatPlace;
					Vector3A oneselfBone;
					long int Mesh = getZZ(Temporary + MeshOffsetAddr);
					long int Human = Mesh + MeshAddressAddr;
					long int Bone = getZZ(Mesh + BoneAddr) + 0x30;

					long int Meshself = getZZ(oneself + MeshOffsetAddr);
					long int Humanself = Meshself + MeshAddressAddr;
					long int Boneself = getZZ(Meshself + BoneAddr) + 0x30;

					if (fengling.aimbotmode == 1)
					{
						aimatPlace = getBoneXYZ(Human, Bone, 5);		  //头部
						oneselfBone = getBoneXYZ(Humanself, Boneself, 5);
					}
					else if (fengling.aimbotmode == 2)
					{
						aimatPlace = getBoneXYZ(Human, Bone, 4);		  //胸部
						oneselfBone = getBoneXYZ(Humanself, Boneself, 4);
					}
					else if (fengling.aimbotmode == 3)
					{
						aimatPlace = getBoneXYZ(Human, Bone, 1);		  //盆部
						oneselfBone = getBoneXYZ(Humanself, Boneself, 1);
					}

					if (TGMPMode == false)
					{
						long int zmAddr = getZZ(getZZ(oneself + zmAddrone) + zmAddrtwo);
						int kh = getDword(oneself + khAddr);			// 开火
						int kj = getDword(oneself + kjAddr);			// 开镜
						long int CameraAddrx = zmAddr + CameraAddr;		//弹道X
						long int CameraAddry = zmAddr + CameraAddr + 4; //弹道Y
						long int CameraAddrz = zmAddr + CameraAddr + 8; //弹道Z
						// printf("%lx\n", CameraAddrz);

						if (kh == 1 && kj != 50 && getDword(oneself + zdAddr) != 0 || fengling.BulletModeSingle == true && kj != 50 && getDword(oneself + zdAddr) != 0)
						{
							if (Temporary != 0)
							{
								WriteFloat(CameraAddrx, aimatPlace.X);
								WriteFloat(CameraAddry, aimatPlace.Y);
								WriteFloat(CameraAddrz, aimatPlace.Z);
							}
							else
							{
								Temporary = 0;
							}
						}
						else
						{
							Temporary = 0;
						}
					}
					else if (TGMPMode == true)
					{
						long int zmAddr = getZZ(getZZ(oneself + zmAddrone) + zmAddrtwo);
						int kh = getDword(getZZ(oneself + 0xCA0) + khAddr); // 开火
						int kj = getDword(oneself + kjAddr);				// 开镜
						long int CameraAddry = zmAddr + CameraAddr;			//枪口Y
						long int CameraAddrx = zmAddr + CameraAddr + 4;		//枪口X
						// printf("%lx\n", CameraAddrz);

						float ZMY = 0,ZMX = 0;

						float cx = aimatPlace.X - oneselfBone.X;
						float cy = aimatPlace.Y - oneselfBone.Y;
						float cz = aimatPlace.Z - oneselfBone.Z;

						float pfg = sqrt((cx * cx) + (cy * cy));
						float XGY = (float)atan2(cz, pfg) * 57.29578;
						if (XGY >= 290)
						{
						    ZMY = XGY - 359.99999;
						}
						else
						{
							ZMY = XGY;
						}
						float XGX = (float)atan2(cy, cx) * 57.29578;
						if (XGX >= 180)
						{
						    ZMX = XGX - 359.99999;
						}
						else
						{
							ZMX = XGX;
						}

						if (kh == 1 && kj != 50 && getDword(oneself + zdAddr) != 0 || fengling.BulletModeSingle == true && kj != 50 && getDword(oneself + zdAddr) != 0)
						{
							if (Temporary != 0)
							{
								WriteFloat(CameraAddry, ZMY);
								WriteFloat(CameraAddrx, ZMX);
							}
							else
							{
								Temporary = 0;
							}
						}
						else
						{
							Temporary = 0;
						}
					}
				}
			}
		}
		send((void *)&resling, sizeof(resling));
	}
	puts("结束运行\n");
	exit(1);
}